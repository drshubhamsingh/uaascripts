## Read the experiment conditions for the samples
plate.names.raw <- NULL
plate.names.raw <- read.csv(file = "Plate Names.csv", header = TRUE, sep = ",")

if (length(plate.names.raw) == 0) {
  print("Plate names are empty. Script will terminate.", quote = FALSE)
  exit()
}

plate.names.raw[plate.names.raw == FALSE] <- as.character("F")
plate.names.raw.columns <- ncol(plate.names.raw)
plate.names.useful <- subset(plate.names.raw, Attributes != "")
sample.attributes <- levels(factor(as.character(plate.names.useful$Attributes)))
samples.per.plate <- length(plate.names.useful$Attributes[plate.names.raw$Attributes == sample.attributes[1]])

plate.name.string <- NULL
for(i in 3:(plate.names.raw.columns-2)) { plate.name.string <- c(plate.name.string, rep(names(plate.names.raw[i]), samples.per.plate)) }

sample.string <- rep(c(1:samples.per.plate), plate.names.raw.columns-4)
well.id.string <- rep(levels(factor(plate.names.useful$Well.Num)), plate.names.raw.columns-4)

plate.names <- data.frame(plate.no = as.character(plate.name.string),
                          sample.no = as.factor(sample.string),
                          well.id = as.character(well.id.string))

plate.names$plate.no <- as.factor(plate.names$plate.no)
plate.names$well.id <- as.factor(plate.names$well.id)

plate.names$well.cp <- NA
for(i in 1:length(levels(plate.names$well.id))) { plate.names$well.cp[plate.names$well.id == levels(plate.names$well.id)[i]] <- levels(factor(as.character(plate.names.raw$Well.CP[plate.names.raw$Well.Num == levels(plate.names$well.id)[i]]))) }

for(i in 1:length(sample.attributes)) {
  
  column.names.plate <- NULL
  column.names.plate <- colnames(plate.names)
  
  temp.names.subset <- NULL
  temp.names.subset <- subset(plate.names.raw, Attributes == sample.attributes[i])
  temp.names.subset[] <- lapply(temp.names.subset, as.character)
  
  temp.samples <- NULL
  for(j in 3:(plate.names.raw.columns-2)) { temp.samples <- c(temp.samples, temp.names.subset[j]) }
  temp.samples <- unname(unlist(temp.samples), force = TRUE)
  
  plate.names[ncol(plate.names)+1] <- temp.samples
  colnames(plate.names) <- c(column.names.plate, sample.attributes[i])
  
  rm(column.names.plate)
  rm(temp.names.subset)
  rm(temp.samples)
  
}
rm(plate.names.raw)
rm(plate.names.useful)

classifications <- NULL
classifications <- read.csv(file = paste(sep = "", sourcecode.path, "Common_File_Classification.txt"), header = TRUE, sep = ",", dec = ".")

classifications$Key <- as.factor(classifications$Key)
allclassifications <- levels(classifications$Key)
plate.names$class.status <- as.character(NA)
plate.names$class.meaning <- as.character(NA)

for(i in 1:length(allclassifications)){
  plate.names$class.status[plate.names$Keyword == allclassifications[i]] <- as.character(classifications$Status[classifications$Key == allclassifications[i]])
  plate.names$class.meaning[plate.names$Keyword == allclassifications[i]] <- as.character(classifications$Meaning[classifications$Key == allclassifications[i]])
}

plate.names <- data.frame(lapply(plate.names, factor), stringsAsFactors = TRUE)
write.table(plate.names, file = paste(generatedfilesfolder, "Plate Names Generated on ", runtime, ".csv", sep = ""),
            append = FALSE, row.names = FALSE, sep = ",", na = "NA", dec = ".", col.names = TRUE, quote = FALSE)
print("Plate Names Loaded. Script will continue...", quote = FALSE)


# Only for CellProfiler Output data-analysis (directorycsv is set to TRUE)
if (directorycsv == TRUE) { 
  
  directories <- list.dirs(path = ".", recursive = FALSE)
  directories <- directories[str_detect(directories, pattern = "./Plate")]
  
  filename1 <- NULL
  filename2 <- NULL
  filename3 <- NULL
  filename4 <- NULL
  filename5 <- NULL
  filename6 <- NULL
  
  for (dirs in 1:length(directories)) {
    
    filename1[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_PrmObjMerge.csv", sep = "")
    filename2[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_Image.csv", sep = "")
    filename3[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_PrmObjMergeAll.csv", sep = "")
    filename4[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_ObjMergeSatBoth.csv", sep = "")
    filename5[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_SatObjmRSP.csv", sep = "")
    filename6[dirs] <- paste(directories[dirs], .Platform$file.sep, "CellProfilerExport_SatObjeGFP.csv", sep = "")
    
  }
  
  rm(dirs)
  print("CSV Filenames Loaded. Script will continue...", quote = FALSE)
  
}

# Only for Endpoint Fluorescence data-analysis (directorycsv is set to FALSE)
if (directorycsv == FALSE) {
  
  filelist <- NULL
  filelist <- list.files(pattern = "*.csv")
  if (length(filelist) == 0) {
    
    print("No CSV Files found. Script will terminate.", quote = FALSE)
    exit()
    
  }
  
  filelist <- filelist[filelist != "Plate Names.csv"]
  filelist <- filelist[str_detect(filelist, pattern = "Plate")]
  
  print("CSV Filenames Loaded. Script will continue...", quote = FALSE)
  
}

peakxfordens <- function(n) {
  
  if(length(n) == 1) { if(is.na(n) == TRUE) { return(NA) } }
  if(length(n) == 0) { return(NA) }
  
  if(length(n) != 0) {
    d <- density(n)
    m <- d$x[d$y == max(d$y)]
    return(m)
  }
  
}

print("Input-Output Settings and Functions Loaded")