## VERY IMPORTANT : Before running this script, use setwd() function to set the working directory.

setwd("/scicore/projects/scicore-p-maiert-structbio/shubham/Login19_Process/SSCP-PL11/210530_210605_Dummy/")

rm(list = ls())

## Path where all the supplementary scripts are present.
sourcecode.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Final_Data/Pipelines/R_Source_Code/"

## Define the layout for the plate
source(file = paste(sep = "", sourcecode.path, "01. Plate Settings.R"))

## Define the parameters for the graphical elements
source(file = paste(sep = "", sourcecode.path, "02. Graphics Settings.R"))

## Ensures that the csv files present in the sub-directories are read
## directorycsv is set to false when the csv files are present in the current directory 
directorycsv <- TRUE

## Defines the plate structure of the experiment and loads the necessary functions
source(file = paste(sep = "", sourcecode.path, "03. Input Output Settings.R"))

cat("Supplementary Scripts Loaded Successfully.")

## "allcpdata" will aggregate all data into one file. "allcpdata" may become huge (> 15 GB)
allcpdata <- NULL

## Process each plate.
for (file.no in 1:length(directories)) {
  
  subdirectory <- NULL
  subdirectory <- sub(paste(".", .Platform$file.sep, sep = ""), "", directories[file.no])
  subdirectory <- paste(subdirectory, .Platform$file.sep, sep = "")
  
  dir.create(path = paste(subdirectory, pdfpath.qc, sep = ""))
  
  filesize <- NULL
  filesizeunit <- NULL
  
  filesize <- file.size(filename1[file.no])/1000
  filesizeunit <- "KB"
  
  if(filesize/1024 > 1.5) {
    filesize <- filesize/1024
    filesizeunit <- "MB"
    if(filesize/1024 > 1.5) {
      filesize <- filesize/1024
      filesizeunit <- "GB"
      if(filesize/1024 > 1.5) {
        filesize <- filesize/1024
        filesizeunit <- "TB"
      }
    }
  }
  
  filesize <- round(filesize, digits = 2)
  
  print(paste(Sys.time(), "- Reading and loading cpdata for directory", file.no, "out of",
              length(directories), "( File Size -", filesize, filesizeunit, ")"), quote = FALSE)
  
  cpdata <- NULL
  
  ## Read all files  
  cpdata <- read.csv(file = filename1[file.no], header = TRUE, sep = ",", dec = ".")
  cpdata.all.objects <- read.csv(file = filename3[file.no], header = TRUE, sep = ",", dec = ".")
  cpdata.saturated.both <- read.csv(file = filename4[file.no], header = TRUE, sep = ",", dec = ".")
  cpdata.saturated.mrsp <- read.csv(file = filename5[file.no], header = TRUE, sep = ",", dec = ".")
  cpdata.saturated.egfp <- read.csv(file = filename6[file.no], header = TRUE, sep = ",", dec = ".")
  cat(paste(Sys.time(), ": CellProfiler output files cpdata is read for the directory", file.no, "out of", length(directories)))
  
  ## well.id and well.column are needed for later processing steps
  cpdata$well.id <- cpdata$Metadata_Well
  cpdata$well.column <- cpdata$Metadata_WellColumn
  cpdata.all.objects$well.id <- cpdata.all.objects$Metadata_Well
  cpdata.all.objects$well.column <- cpdata.all.objects$Metadata_WellColumn
  cpdata.saturated.both$well.id <- cpdata.saturated.both$Metadata_Well
  cpdata.saturated.both$well.column <- cpdata.saturated.both$Metadata_WellColumn
  cpdata.saturated.mrsp$well.id <- cpdata.saturated.mrsp$Metadata_Well
  cpdata.saturated.mrsp$well.column <- cpdata.saturated.mrsp$Metadata_WellColumn
  cpdata.saturated.egfp$well.id <- cpdata.saturated.egfp$Metadata_Well
  cpdata.saturated.egfp$well.column <- cpdata.saturated.egfp$Metadata_WellColumn
  
  ## Add cpdata to allcpdata
  allcpdata <- rbind(allcpdata, cpdata)
  
  ## Add experiment-date,experiment-time, plate-date and plate-time to create unique ID for plates 
  expmtdate <- levels(factor(cpdata$Metadata_ExpDate))
  expmttime <- levels(factor(cpdata$Metadata_ExpTime))
  platedate <- levels(factor(cpdata$Metadata_PlateDate))
  if (length(platedate) == 0) { platedate <- expmtdate } # Since plate-date may not always be present
  platename <- levels(factor(cpdata$Metadata_PlateName))
  platetime <- levels(factor(cpdata$Metadata_PlateTime))
  if (length(platetime) == 0) { platetime <- expmttime } # Since plate-time may not always be present
  
  ## Defines the name of the output-file for the current plate for current experiment
  outputfile <- paste(expmtdate, " ", expmttime, " ", platename, sep= "")
  
  ## For separating the data based on the the kinetic position of the images
  allkineticreads <- levels(factor(cpdata$Metadata_KineticPosition))
  
  ## "useful.cpdata" is a data-frame used for holding the shortlisted information on individual objects.
  ## Extracting this information from cpdata reduces the size of data by 10-fold.
  useful.cpdata <- NULL
  useful.cpdata <-
    data.frame(
      well.id = factor(),
      well.row = character(),
      well.column = integer(),
      objegfp.total = double(),
      objmrsp.total = double(),
      GRratio.total.1c = double(),
      objegfp.median  = double(),
      objmrsp.median = double(),
      GRratio.median.1c = double(),
      objegfp.max = double(),
      objmrsp.max = double(),
      obj.area = integer(),
      obj.x.axis = integer(),
      obj.y.axis = integer(),
      kinetic.position = integer(),
      object.number = integer(),
      bottom.or.top = character(),
      stringsAsFactors = FALSE
    )
  
  ## "results.one.well" dataframe is used for storing the summarized data after manual processing.
  ## Processing the data using this script allows necessary modifications (such as excluding outliers)
  results.one.well <- NULL
  results.one.well <-
    data.frame(
      well.id = character(),
      well.row = character(),
      well.column = integer(),
      grd.sum.objegfp = double(),
      grd.sum.objmrsp = double(),
      GRratio.intgfirst.1w = double(),
      GRratio.g2rfirst.1w = double(),
      GRratio.peakdens.1w = double(),
      initial.count = integer(),
      final.count = integer(),
      n10ct.well.egfp = double(),
      n10ct.well.mrsp = double(),
      kinetic.position = integer(),
      bottom.or.top = character(),
      stringsAsFactors = FALSE
    )
  
  ## For each kinetic-read shortlist the data based on defined cutoffs
  for (kinet in 1:length(allkineticreads)) {
    
    temp.useful.cpdata <- NULL
    
    kinetic.position <- allkineticreads[kinet]
    cpdata.kinetic <- subset(x = cpdata, subset = cpdata$Metadata_KineticPosition == kinetic.position)
    cpdata.all.objects.kinetic <- subset(x = cpdata.all.objects, subset = cpdata.all.objects$Metadata_KineticPosition == kinetic.position)
    cpdata.saturated.both.kinetic <- subset(x = cpdata.saturated.both, subset = cpdata.saturated.both$Metadata_KineticPosition == kinetic.position)
    cpdata.saturated.mrsp.kinetic <- subset(x = cpdata.saturated.mrsp, subset = cpdata.saturated.mrsp$Metadata_KineticPosition == kinetic.position)
    cpdata.saturated.egfp.kinetic <- subset(x = cpdata.saturated.egfp, subset = cpdata.saturated.egfp$Metadata_KineticPosition == kinetic.position)
    
    # Used for naming the file-names
    read.text <- paste("Read", allkineticreads[kinet])
    
    ## Level 1 quality control - Quality Control of the data provided by the CellProfiler
    if(cpqc == TRUE){ source(file = paste(sep = "", sourcecode.path, "06. CellProfiler Quality Control.R")) }
    
    ## Calculations and Summary
    for (i in 1:length(well.name)) {
      
      cat(paste("Processing the well", as.character(well.name[i]), "for kinetic read", kinet, "of plate", file.no, "\n"))
      
      cpdata.kinetic.well <- subset(x = cpdata.kinetic, subset = cpdata.kinetic$well.id == well.name[i])
      
      n10ct.egfp <- mean(cpdata.kinetic.well$Intensity_IntegratedIntensity_eGFP, na.rm = TRUE)
      n10ct.mrsp <- mean(cpdata.kinetic.well$Intensity_IntegratedIntensity_mRSP, na.rm = TRUE)
      
      if(is.nan(n10ct.egfp)) { n10ct.egfp <- NA }
      if(is.nan(n10ct.mrsp)) { n10ct.mrsp <- NA }
      
      well.row <- gsub(x = well.name[i], pattern = "[0-9]", replacement = "")
      well.column <- gsub(x = well.name[i], pattern = "[A-Z]", replacement = "")
      
      # If the number of objects in the current well is less than 200, ignore the well and substitute the information with 'NA'
      if (length(cpdata.kinetic.well$ObjectNumber) < 200) {
        
        if (length(n10ct.egfp) == 0) {
          n10ct.egfp <- NA
        }
        
        if (length(n10ct.mrsp) == 0) {
          n10ct.mrsp <- NA
        }
        
        results.one.well.temp <- NULL
        
        results.one.well.temp <-
          data.frame(
            well.name[i],
            well.row,
            well.column,
            NA,
            NA,
            NA,
            NA,
            NA,
            NA,
            NA,
            n10ct.egfp,
            n10ct.mrsp,
            kinetic.position,
            names(well.name[i])
          )
        
        names(results.one.well.temp) <-
          c(
            "well.id",
            "well.row",
            "well.column",
            "grd.sum.objegfp",
            "grd.sum.objmrsp",
            "GRratio.intgfirst.1w",
            "GRratio.g2rfirst.1w",
            "GRratio.peakdens.1w",
            "initial.count",
            "final.count",
            "n10ct.well.egfp",
            "n10ct.well.mrsp",
            "kinetic.position",
            "bottom.or.top"
          )
        
        results.one.well <- rbind(results.one.well, results.one.well.temp)
        
        rm(results.one.well.temp)
        
      }
      
      ## If the number of objects in the current well are more than 200, extract summary
      if (length(cpdata.kinetic.well$ObjectNumber) >= 200) {
        
        number.initial <- NULL
        number.initial <- length(cpdata.kinetic.well$ObjectNumber)
        
        ## Extract Area information from the shortlisted data          
        if(length(cpdata.kinetic.well$AreaShape_Area) != 0) { obj.area.temp <- cpdata.kinetic.well$AreaShape_Area }
        if(length(cpdata.kinetic.well$AreaShape_Area) == 0) { obj.area.temp <- NA }
        
        ## Extract eGFP Information and set less than 0 values to 0
        objegfp.total.temp <- cpdata.kinetic.well$Intensity_IntegratedIntensity_eGFP
        objegfp.total.temp[objegfp.total.temp < 0] <- 0
        
        ## Extract mRSP Information and set less than 0 values to NA (mRSP is in denominator and hence should not be 0)
        objmrsp.total.temp <- cpdata.kinetic.well$Intensity_IntegratedIntensity_mRSP
        objmrsp.total.temp[objmrsp.total.temp < 0] <- NA
        
        # GRratio.total.1c is G2R value FOR THE OBJECT (calculated from total eGFP and total mRSP of the object) 
        GRratio.total.1c <- NULL
        GRratio.total.1c <- objegfp.total.temp / objmrsp.total.temp
        
        # Ignoring GRratio values where GRratio is NA
        grratio.extraction <- !is.na(GRratio.total.1c)
        
        # Removing those values where GRratio is NA
        GRratio.total.1c <- GRratio.total.1c[grratio.extraction]
        objegfp.total.temp <- objegfp.total.temp[grratio.extraction]
        objmrsp.total.temp <- objmrsp.total.temp[grratio.extraction]
        obj.area.temp <- obj.area.temp[grratio.extraction]
        
        # grd.sum.objegfp is total eGFP in the well for current kinetic read 
        grd.sum.objegfp <- sum(objegfp.total.temp, na.rm = TRUE)
        
        # grd.sum.objegfp is total mRSP in the well for current kinetic read
        grd.sum.objmrsp <- sum(objmrsp.total.temp, na.rm = TRUE)
        
        # objegfp.max.temp is the MAX eGFP-Intensity of the objects in the current well (Calculated by CellProfiler)
        objegfp.max.temp <- cpdata.kinetic.well$Intensity_MaxIntensity_eGFP
        objegfp.max.temp <- objegfp.max.temp[grratio.extraction]
        
        # objmrsp.max.temp is the MAX mRSP-Intensity of the objects in the current well (Calculate by CellProfiler)
        objmrsp.max.temp <- cpdata.kinetic.well$Intensity_MaxIntensity_mRSP
        objmrsp.max.temp <- objmrsp.max.temp[grratio.extraction]
        
        # objegfp.median.temp is the MEDIAN eGFP-Intensity of the objects in the current well (calculated by CellProfiler)
        objegfp.median.temp <- cpdata.kinetic.well$Intensity_MedianIntensity_eGFP
        objegfp.median.temp <- objegfp.median.temp[grratio.extraction]
        
        # objmrsp.median.temp is the MEDIAN mRSP-Intensity of the objects in the current well (calculated by CellProfiler)
        objmrsp.median.temp <- cpdata.kinetic.well$Intensity_MedianIntensity_mRSP
        objmrsp.median.temp <- objmrsp.median.temp[grratio.extraction]
        
        # GRratio.median.1c is G2R value FOR THE OBJECT (calculated from median eGFP and median mRSP of the object)
        GRratio.median.1c <- objegfp.median.temp / objmrsp.median.temp
        
        # object.number.temp is the Index assigned to the object by  CellProfiler
        object.number.temp <- cpdata.kinetic.well$ObjectNumber
        object.number.temp <- object.number.temp[grratio.extraction]
        
        # object.xaxis.temp is X-Axis of the object Calculated by Cell Profiler
        object.xaxis.temp <- cpdata.kinetic.well$AreaShape_Center_X
        object.xaxis.temp <- object.xaxis.temp[grratio.extraction]
        
        # object.yaxis.temp is Y-Axis of the object Calculated by Cell Profiler
        object.yaxis.temp <- cpdata.kinetic.well$AreaShape_Center_Y
        object.yaxis.temp <- object.yaxis.temp[grratio.extraction]
        
        number.final <- length(GRratio.total.1c)
        
        ## We are setting a second cutoff here.
        ## Only images, where at least 50 cells have a higher signal than the background will be considered.
        if(number.final >= 50) {
          
          #8.1 used for storing shortlisted object-data
          {
            
            useful.cpdata.temp <- NULL
            useful.cpdata.temp <-
              data.frame(
                rep(well.name[i], times = number.final),
                rep(well.row, times = number.final),
                rep(well.column, times = number.final),
                objegfp.total.temp,
                objmrsp.total.temp,
                GRratio.total.1c,
                objegfp.median.temp,
                objmrsp.median.temp,
                GRratio.median.1c,
                objegfp.max.temp,
                objmrsp.max.temp,
                obj.area.temp,
                object.xaxis.temp,
                object.yaxis.temp,
                rep(kinetic.position, times = number.final),
                object.number.temp,
                rep(names(well.name[i]), times = number.final)
              )
            
            names(useful.cpdata.temp) <-
              c(
                "well.id",
                "well.row",
                "well.column",
                "objegfp.total",
                "objmrsp.total",
                "GRratio.total.1c",
                "objegfp.median",
                "objmrsp.median",
                "GRratio.median.1c",
                "objegfp.max",
                "objmrsp.max",
                "obj.area",
                "obj.x.axis",
                "obj.y.axis",
                "kinetic.position",
                "object.number",
                "bottom.or.top"
              )
            
            useful.cpdata <- rbind(useful.cpdata, useful.cpdata.temp)
            
            if(is.null(temp.useful.cpdata)) { temp.useful.cpdata <- useful.cpdata.temp }
            
            if(!is.null(temp.useful.cpdata)) { temp.useful.cpdata <- rbind(temp.useful.cpdata, useful.cpdata.temp) }
            
          }  #8.1
          
          #8.2 used for storing averaged data
          {
            
            results.one.well.temp <- NULL
            results.one.well.temp <-
              data.frame(
                well.name[i],
                well.row,
                well.column,
                grd.sum.objegfp,
                grd.sum.objmrsp,
                grd.sum.objegfp/grd.sum.objmrsp,
                mean(objegfp.total.temp / objmrsp.total.temp),
                peakxfordens(objegfp.total.temp/objmrsp.total.temp),
                number.initial,
                number.final,
                n10ct.egfp,
                n10ct.mrsp,
                kinetic.position,
                names(well.name[i])
              )
            
            names(results.one.well.temp) <-
              c(
                "well.id",
                "well.row",
                "well.column",
                "grd.sum.objegfp",
                "grd.sum.objmrsp",
                "GRratio.intgfirst.1w",
                "GRratio.g2rfirst.1w",
                "GRratio.peakdens.1w",
                "initial.count",
                "final.count",
                "n10ct.well.egfp",
                "n10ct.well.mrsp",
                "kinetic.position",
                "bottom.or.top"
              )
            
            results.one.well <- rbind(results.one.well, results.one.well.temp)
            
          }  #8.2
          
          #8.3 clean memory
          {
            
            rm(useful.cpdata.temp)
            rm(results.one.well.temp)
            
            rm(obj.area.temp)
            rm(objegfp.total.temp)
            rm(objmrsp.total.temp)
            
          }  #8.3
          
        }
        
        ## For less than 50 objects, ignore the results
        if(number.final < 50) {
          
          if (length(n10ct.egfp) == 0) { n10ct.egfp <- NA }
          if (length(n10ct.mrsp) == 0) { n10ct.mrsp <- NA }
          
          results.one.well.temp <- NULL
          results.one.well.temp <-
            data.frame(
              well.name[i],
              well.row,
              well.column,
              NA,
              NA,
              NA,
              NA,
              NA,
              NA,
              NA,
              n10ct.egfp,
              n10ct.mrsp,
              kinetic.position,
              names(well.name[i])
            )
          
          names(results.one.well.temp) <-
            c(
              "well.id",
              "well.row",
              "well.column",
              "grd.sum.objegfp",
              "grd.sum.objmrsp",
              "GRratio.intgfirst.1w",
              "GRratio.g2rfirst.1w",
              "GRratio.peakdens.1w",
              "initial.count",
              "final.count",
              "n10ct.well.egfp",
              "n10ct.well.mrsp",
              "kinetic.position",
              "bottom.or.top"
            )
          
          results.one.well <- rbind(results.one.well, results.one.well.temp)
          
          rm(results.one.well.temp)
          
        }
        
      }
      
    }
    
    ## QC Plot 10 - To see which objects are shortlisted 
    cat("Plotting Shortlisted Objects...\n")
    
    pdf(
      file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 10. Shortlisted Object Distribution.pdf", sep = ""),
      height = posterpdfheight,
      width = posterpdfwidth
    )
    
    par(mfrow = c(scatterplotrows, scatterplotcolumns))
    
    for (i in 1:length(well.name)) {
      
      truthvalue <- NULL
      truthvalue <- temp.useful.cpdata$well.id == well.name[i]
      
      # Plotting the data
      plotxtemp <- NA
      plotytemp <- NA
      
      plotxtemp <- temp.useful.cpdata$obj.x.axis[truthvalue]
      plotytemp <- temp.useful.cpdata$obj.y.axis[truthvalue]
      
      if (length(plotxtemp) >= 200) {
        
        range.max <- round(max(plotxtemp, plotytemp), 0)
        range.min <- round(min(0, plotxtemp, plotytemp), 0)
        
      }
      
      if (length(plotxtemp) < 200) {
        
        range.max <- round(max(temp.useful.cpdata$obj.x.axis, temp.useful.cpdata$obj.y.axis), 0)
        range.min <- round(min(0, temp.useful.cpdata$obj.x.axis, temp.useful.cpdata$obj.y.axis, 0), 0)
        
        if(is.infinite(range.max)) {
          
          range.max <- round(max(cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
          
        }
        
      }
      
      if(length(plotxtemp) == 0) {
        
        plot(-100,-100, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis",
             main = paste("No Data Found. Display cancelled for", well.name[i]),
             axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
        
        axis(1)
        axis(2)
        
      }
      
      if(length(plotxtemp) != 0) {
        
        plot(plotytemp ~ plotxtemp, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis",
             main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
             xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
        
        axis(1)
        axis(2)
        
      }
      
    }
    
    dev.off()
    cat("\n", paste("Kinetic set", kinet, "completed.\n"))
    
  }
  rm(temp.useful.cpdata)
  
  # If it is not already as levels, convert well.id to levels
  useful.cpdata$well.id <- as.factor(useful.cpdata$well.id)
  
  # Remove the temporary data-frame to save memory 
  rm(cpdata.kinetic)
  rm(cpdata.all.objects.kinetic)
  rm(cpdata.saturated.both.kinetic)
  rm(cpdata.saturated.mrsp.kinetic)
  rm(cpdata.saturated.egfp.kinetic)
  
  ## Allocate 'Attributes' to the newly created data-frames results.one.well
  print(paste(Sys.time(), "Allocating the Attributes for results.one.well for file ", file.no, "out of", length(directories)), quote = FALSE)
  allocate.dataframe <- results.one.well
  source(file = paste(sep = "", sourcecode.path, "04. Allocate Group.R"))
  sample.detail.df <- allocate.dataframe
  source(file = paste(sep = "", sourcecode.path, "05. Sample Detail.R"))
  results.one.well <- sample.detail.df
  rm(sample.detail.df)
  rm(allocate.dataframe)
  results.one.well$kinetic.position <- factor(results.one.well$kinetic.position)
  results.one.well$well.row <- factor(results.one.well$well.row)
  results.one.well$well.column <- factor(results.one.well$well.column)
  results.one.well$bottom.or.top <- factor(results.one.well$bottom.or.top)
  
  ## Allocate 'Attributes' to the newly created data-frames useful.cpdata
  print(paste(Sys.time(), "Allocating the Attributes for useful.cpdata for file ", file.no, "out of", length(directories)), quote = FALSE)
  allocate.dataframe <- useful.cpdata
  source(file = paste(sep = "", sourcecode.path, "04. Allocate Group.R"))
  useful.cpdata <- allocate.dataframe
  sample.detail.df <- useful.cpdata
  source(file = paste(sep = "", sourcecode.path, "05. Sample Detail.R"))
  useful.cpdata <- sample.detail.df
  rm(sample.detail.df)
  rm(allocate.dataframe)
  useful.cpdata$kinetic.position <- factor(useful.cpdata$kinetic.position)
  useful.cpdata$well.row <- factor(useful.cpdata$well.row)
  useful.cpdata$well.column <- factor(useful.cpdata$well.column)
  useful.cpdata$bottom.or.top <- factor(useful.cpdata$bottom.or.top)
  
  ## Calculate Normalized Expression Ratio for Current Plate (Individually for Each Kinetic Read)
  results.one.well$Norm.GRratio.intgfirst.1w <- NA
  results.one.well$Norm.GRratio.g2rfirst.1w <- NA
  results.one.well$Norm.GRratio.peakdens.1w <- NA
  results.one.well$read.time <- NA
  kinpos <- levels(results.one.well$kinetic.position)
  
  for (kinetk in 1:length(kinpos)) {
    
    shortlistkine <- results.one.well$kinetic.position == kinetk
    denominate <- results.one.well$kinetic.position == kinetk & results.one.well$system.Detail == "All Control Both"
    
    results.one.well$Norm.GRratio.intgfirst.1w[shortlistkine] <-
      results.one.well$GRratio.intgfirst.1w[shortlistkine] *
      100 / mean(results.one.well$GRratio.intgfirst[denominate], na.rm = TRUE)
    
    results.one.well$Norm.GRratio.g2rfirst.1w[shortlistkine] <-
      results.one.well$GRratio.g2rfirst.1w[shortlistkine] *
      100 / mean(results.one.well$GRratio.g2rfirst.1w[denominate], na.rm = TRUE)
    
    results.one.well$Norm.GRratio.peakdens.1w[shortlistkine] <-
      results.one.well$GRratio.peakdens.1w[shortlistkine] *
      100 / mean(results.one.well$GRratio.peakdens.1w[denominate], na.rm = TRUE)
    
    results.one.well$read.time[shortlistkine] <-
      paste("Read ", kinetk, "\t", allreadtimes[kinetk], " Hours", sep = "")
    
  }
  
  rm(shortlistkine)
  rm(denominate)
  
  ## Add plate and experiment metadata
  results.one.well$platedate <- platedate
  results.one.well$platetime <- platetime
  results.one.well$platename <- platename
  
  plate.uid <- paste(platedate, platetime, platename, sep = "-")
  
  results.one.well$plateuid <- paste("UID", file.no, results.one.well$platedate, results.one.well$platetime, sep = "")
  
  dir.create(path = paste(subdirectory, excelpath, sep = ""))
  dir.create(path = paste(subdirectory, pdfpath, sep = ""))
  
  ## Export all the data
  print("Writing permanent files. This will take some time ....", quote = FALSE)
  
  constant.file <- paste(generatedfilesfolder, "All Plates CP Wells Summary (Analysis Started - ", runtime, ").csv", sep = "")
  aggregating.file <- paste(generatedfilesfolder, "CP Wells Summary Aggregating File.csv", sep = "")
  
  file.list <- paste(generatedfilesfolder, list.files(path = generatedfilesfolder), sep = "")
  
  if (length(file.list[file.list == constant.file]) != 0) {
    write.table(results.one.well, file = constant.file, append = TRUE, row.names = FALSE, sep = ",",
                na = "NA", dec = ".", col.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == constant.file]) == 0) {
    write.csv(results.one.well, file = constant.file, na = "NA", row.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == aggregating.file]) != 0) {
    write.table(results.one.well, file = aggregating.file, append = TRUE, row.names = FALSE, sep = ",", na = "NA",
                dec = ".", col.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == aggregating.file]) == 0) {
    write.csv(results.one.well, file = aggregating.file, na = "NA", row.names = FALSE, quote = FALSE)
  }
  
  print("Writing useful.cpdata to HDD ......", quote = FALSE)
  write.csv(useful.cpdata, file = paste(subdirectory, excelpath, "CSV 1. Trimmed cpdata, runtime ", runtime,".csv", sep = ""),
            na = "NA", row.names = FALSE, quote = FALSE)
  write.csv(results.one.well, file = paste(subdirectory, excelpath, "CSV 2. Well Summary, runtime ", runtime,".csv", sep = ""),
            na = "NA", row.names = FALSE, quote = FALSE)
  
  ## Graphics calculations for current plate
  print("Graphics calculations going on for current plate.", quote = FALSE)
  kinetk <- NULL
  
  ## Plot graphs one by one for each kinetic read
  for (kinetk in 1:length(kinpos)) {
    
    plottingsubset <- subset(x = useful.cpdata, subset = useful.cpdata$kinetic.position == kinpos[kinetk])
    resultssubset <- subset(x = results.one.well, subset = results.one.well$kinetic.position == kinpos[kinetk])
    read.text <- paste("Read", kinpos[kinetk])
    
    print(paste("Plotting histogram and scatter plot for Read", kinetk), quote = FALSE)
    
    ## Plot 1 - Histogram summary of well data
    pdf(file = paste(subdirectory, pdfpath, read.text, " - Plot 1. Histogram - All Wells.pdf", sep = ""),
        height = posterpdfheight, width = posterpdfwidth)
    
    par(mfrow = c(scatterplotrows, scatterplotcolumns))
    
    for (i in 1:length(well.name)) {
      
      truthvalue <- NULL
      truthvalue <- plottingsubset$well.id == well.name[i]
      
      if (length(plottingsubset$GRratio.total.1c[truthvalue]) < 100) {
        
        plot(-1, -1, xlab = "G2R Value", ylab = "Count", main = paste("< 100 values. Display cancelled for", well.name[i]),
             pch = 3, axes = FALSE, xlim = c(0, 0.25), ylim = c(0, 10))
        
        axis(1)
        axis(2)
        
      }
      
      if (length(plottingsubset$GRratio.total.1c[truthvalue]) >= 100) {
        
        grn <- sum(plottingsubset$objegfp.total[truthvalue])
        red <- sum(plottingsubset$objmrsp.total[truthvalue])
        
        dens <- density(plottingsubset$GRratio.total.1c[truthvalue])
        
        peakx <- dens$x[dens$y == max(dens$y)]
        peaky <- max(dens$y)
        
        
        # Histogram plot
        
        hist(plottingsubset$GRratio.total.1c[truthvalue], main = paste("Expression Ratio distribution for Well", well.name[i]),
             xlab = "Expression Ratio", col = colorhue(grn, red, 0.1), ylim = c(0, 1.5 * peaky),
             border = object.details.histogram.border, breaks = object.details.histogram.breaks,
             probability = TRUE)
        
        lines(dens, col = object.details.densityline.color,
              lwd = object.details.densityline.width, lty = object.details.densityline.type)
        
        abline(v = peakx, lwd = 1.5, col = rgb(0, 0, 1, 0.5), lty = "longdash")
        text(peakx, 1.1 * max(dens$y), pos = 4, col = rgb(0, 0, 1, 1), srt = 90, cex = 1.2,
             labels = paste("Peak =", round(peakx, 2)), offset = -0.75)
        
        meantext <- NULL
        meantext <- sum(plottingsubset$objegfp.total[truthvalue]) / sum(plottingsubset$objmrsp.total[truthvalue])
        
        abline(v = meantext, lwd = 1.5, col = rgb(1, 0, 0, 0.5), lty = "longdash")
        text(meantext, 1.1 * max(dens$y), pos = 4, lwd = 2, col = rgb(1, 0, 0, 1), offset = 0.75,
             srt = 90, cex = 1.2, labels = paste("Mean =", round(meantext, 2)))
        
        text(0.8 * max(dens$x), 1.1 * max(dens$y), pos = 1, col = rgb(0, 0, 1, 1),
             cex = 1.5, srt = 0, labels = paste("n = ", length(plottingsubset$GRratio.total.1c[truthvalue]), sep = ""))
        
        abline(v = 0.25, col = rgb(1, 0, 0, 0.5), lty = "dotted", lwd = 0.5)
        abline(v = 1.0, col = rgb(0.5, 0.5, 0, 0.5), lty = "dotted", lwd = 0.5)
        abline(v = 2.0, col = rgb(0, 1, 0, 0.5), lty = "dotted", lwd = 0.5)
        abline(v = 15, col = rgb(1, 1, 1, 0.5), lty = "dotted", lwd = 0.5)
        
        text(0.25, 1.45 * max(dens$y), pos = 4, col = rgb(1, 0, 0, 1), srt = 90, labels = "0.25", cex = 0.75)
        text(1.0, 1.45 * max(dens$y), pos = 4, col = rgb(0.5, 0.5, 0, 1), srt = 90, labels = "1.0", cex = 0.75)
        text(2.0, 1.45 * max(dens$y), pos = 4, col = rgb(0, 1, 0, 1), srt = 90, labels = "2.0", cex = 0.75)
        text(15.0, 1.45 * max(dens$y), pos = 4, col = rgb(1, 1, 1, 1), srt = 90, labels = "15.0", cex = 0.75)
        
      }
      
    }
    dev.off()
    
    ## Plot 2 - Scatter plot of well data
    pdf(file = paste(subdirectory, pdfpath, read.text, " - Plot 2. Scatter Plot - All Wells.pdf", sep = ""),
        height = posterpdfheight, width = posterpdfwidth)
    
    par(mfrow = c(scatterplotrows, scatterplotcolumns))
    
    for (i in 1:length(well.name)) {
      
      truthvalue <- NULL
      truthvalue <- plottingsubset$well.id == well.name[i]
      
      if (length(plottingsubset$GRratio.total.1c[truthvalue]) < 100) {
        
        plot(-1, -1, xlab = "Total mRSP in Cell", ylab = "Total eGFP in Cell",
             main = paste("< 100 values. Display cancelled for", well.name[i]),
             sub = paste("Sample Detail:", levels(as.factor(as.character(results.one.well$system.Detail[results.one.well$well.id == well.name[i]])))),
             pch = 3, axes = FALSE, xlim = c(0, 0.25), ylim = c(0, 10))
        
        axis(1)
        axis(2)
        
      }
      
      if (length(plottingsubset$GRratio.total.1c[truthvalue]) >= 100) {
        
        plotytemp <- plottingsubset$objegfp.total[truthvalue]
        plotxtemp <- plottingsubset$objmrsp.total[truthvalue]
        
        plot(plotytemp ~ plotxtemp, col = rgb(1, 1, 1, 0), pch = 16,
             main = paste("Total eGFP vs mRSP in well", well.name[i]),
             sub = paste("Sample Detail:", levels(as.factor(as.character(results.one.well$system.Detail[results.one.well$well.id == well.name[i]])))),
             xlim = c(0, 200), ylim = c(0, 200),
             xlab = "Total mRSP in Cell", ylab = "Total eGFP in Cell", axes = FALSE)
        
        axis(1)
        axis(2)
        
        for (k in 1:length(plotxtemp)) {
          
          hue <- colorhue(plotytemp[k], plotxtemp[k], 0.25)
          points(plotxtemp[k], plotytemp[k], col = hue, pch = 16)
          
        }
        
        slope <- resultssubset$GRratio.intgfirst.1w[resultssubset$well.id == well.name[i]]
        
        abline(a = 0, b = slope, lwd = 2, col = rgb(0, 0, 1, 0.5), lty = "longdash")
        
        text(150, 180, pos = 1, col = rgb(0, 0, 1, 1), cex = 1.5, srt = 0,
             labels = paste("Slope (Ratio): ", round(slope, 2), "\n", "n = ", length(plotytemp), sep = ""))
        
      }
      
    }
    dev.off()
    par(mfrow = c(1, 1))
    
    ## Plot 3 - Violin-Plot for GRratio distribution for all wells
    if(is.infinite(max(plottingsubset$GRratio.total.1c, na.rm = TRUE)) == FALSE) {
      
      labeltext <- NULL
      labeltext <- aggregate(GRratio.total.1c ~ well.id, plottingsubset, mean)
      labeltext$GRratio.total.1c <- paste("Mean:", round(labeltext$GRratio.total.1c, 2))
      
      labeltext$count <- NULL
      
      for (i in 1:length(labeltext$well.id)) {
        
        labeltext$count[labeltext$well.id == labeltext$well.id[i]] <-
          resultssubset$final.count[resultssubset$well.id == as.character(labeltext$well.id[i])]
        
      }
      
      labeltext$GRratio.total.1c <- paste(labeltext$GRratio.total.1c, ". Count: ", labeltext$count, sep = "")
      
      plotstore <- NULL
      
      ## Plot 3 Violin plot of all wells
      plotstore <- ggplot(data = plottingsubset, aes(x = GRratio.total.1c, y = well.id)) +
        
        geom_violin(fill = object.details.violin.fill, width = object.details.violin.width, scale = "width", na.rm = TRUE) +
        
        coord_cartesian(xlim = c(-3, 7)) +
        
        labs(title = "Expression Ratio (total eGFP in cell/ total mRSP in cell)",
             x = object.details.xaxis.label, y = object.details.yaxis.label) +
        
        theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1)) +
        
        stat_summary(fun = mean, na.rm = TRUE, geom = "point", size = object.details.data.size,
                     color = object.details.data.color, shape = object.details.data.shape) +
        
        geom_text(data = labeltext, aes(x = -1.5, label = GRratio.total.1c), col = object.details.text.color) +
        
        geom_vline(xintercept = 0, col = "red", lwd = 0.2, show.legend = FALSE, lty = control.min.line.type)
      
      ggsave(plot = plotstore, device = "pdf", width = mediumpdfwidth, height = mediumpdfheight, units = "in", limitsize = FALSE,
             filename = paste(subdirectory, pdfpath, read.text, " - Plot 3 - GRratio dist (wells).pdf", sep = ""))
      
    }
    
    ## Plot 4 - Violin-Plot for all conditions
    if(is.infinite(max(plottingsubset$GRratio.total.1c, na.rm = TRUE)) == FALSE) {
      
      labeltext <- NULL
      labeltext <- aggregate(GRratio.total.1c ~ system.Detail, plottingsubset, mean)
      labeltext$GRratio.total.1c <- paste("Mean:", round(labeltext$GRratio.total.1c, 2))
      
      plotstore <- NULL
      plotstore <- ggplot(data = plottingsubset, aes(x = GRratio.total.1c, y = system.Detail)) +
        
        geom_violin(fill = object.details.violin.fill, width = object.details.violin.width, scale = "width", na.rm = TRUE) +
        
        coord_cartesian(xlim = c(-1, 6)) +
        
        labs(title = "Expression Ratio (total eGFP in cell/ total mRSP in cell)",
             x = object.details.xaxis.label, y = object.details.yaxis.label) +
        
        theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1 )) +
        
        stat_summary(fun = mean, na.rm = TRUE, geom = "point", size = object.details.data.size,
                     color = object.details.data.color, shape = object.details.data.shape) +
        
        geom_text(data = labeltext, aes(x = -0.75, label = GRratio.total.1c), col = object.details.text.color) +
        
        geom_vline(xintercept = 0, col = "red", lwd = 0.2, show.legend = FALSE, lty = control.min.line.type)
      
      ggsave(plot = plotstore, device = "pdf", width = smallpdfwidth, height = smallpdfheight, units = "in", limitsize = FALSE,
             filename = paste(subdirectory, pdfpath, read.text, " - Plot 4 - GRratio dist (type).pdf", sep = ""))
      
    }
    
    ## Plot 5 - Box-Plot of expression ratio of all sample types
    if(is.infinite(max(resultssubset$Norm.GRratio.intgfirst.1w, na.rm = TRUE)) == FALSE) {
      
      blueline <- NULL
      redline <- NULL
      blueline <- round(mean(resultssubset$Norm.GRratio.intgfirst.1w[resultssubset$system.Detail == "All Control Both"], na.rm = TRUE), 2)
      redline <- round(mean(resultssubset$Norm.GRratio.intgfirst.1w[resultssubset$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
      
      labeltext <- NULL
      labeltext <- aggregate(Norm.GRratio.intgfirst.1w ~ system.Detail, resultssubset, mean)
      labeltext$Norm.GRratio.intgfirst.1w <- paste("Mean: ", round(labeltext$Norm.GRratio.intgfirst.1w, 0), "%", sep = "")
      
      labelpos <- NULL
      labelpos <- aggregate(Norm.GRratio.intgfirst.1w ~ system.Detail, resultssubset, max)
      labeltext$labelpos <- round(labelpos$Norm.GRratio.intgfirst.1w, 2)
      
      plotstore <- NULL
      plotstore <- ggplot(data = resultssubset, aes(x = Norm.GRratio.intgfirst.1w, y = system.Detail)) +
        
        geom_boxplot(fill = object.details.violin.fill, width = object.details.violin.width, na.rm = TRUE) +
        
        coord_cartesian(xlim =c(-15, 115)) +
        
        labs(title = "Expression Ratio (total eGFP/ total mRSP); Grouped by sample types",
             x = object.details.xaxis.label, y = object.details.yaxis.label) +
        
        theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1)) +
        
        geom_point(size = object.details.points.size, color = object.details.points.color, shape = object.details.points.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "top.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color,
                   shape = object.details.topwells.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "bottom.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color,
                   shape = object.details.bottomwells.shape) +
        
        stat_summary(fun = mean, na.rm = TRUE, geom = "point", size = object.details.data.size,
                     color = object.details.data.color, shape = object.details.data.shape) +
        
        geom_text(data = labeltext, aes(x = labelpos + 10, label = Norm.GRratio.intgfirst.1w), col = object.details.text.color) +
        
        geom_vline(xintercept = blueline, col = control.max.line.color, lwd = control.min.line.width,
                   show.legend = TRUE, lty = control.min.line.type) +
        
        geom_vline(xintercept = redline, col = control.min.line.color, lwd = control.min.line.width, show.legend = TRUE,
                   lty = control.min.line.type) +
        
        guides(colour = guide_legend(title = "Sample Set")) + theme(legend.position = "none") +
        
        annotate(geom = "text", srt = 90, col = control.max.text.color, x = blueline + 10,
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 label = paste("Control: Tandem mRSP-eGFP Present.\nValue:", round(blueline, 2))) +
        
        annotate(geom = "text", x = redline - 10, srt = 90, col = control.min.text.color,
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 label = paste("Control: Only mRSP Present.\nValue:", round(redline, 2)))
      
      ggsave(plot = plotstore, device = "pdf", width = smallpdfwidth, height = smallpdfheight, units = "in", limitsize = FALSE,
             filename = paste( subdirectory, pdfpath, read.text, " - Plot 5 - GR ratio Expression (samples).pdf", sep = ""))
      
    }
    
    ## Plot 6 - Box-plot of peak values ratio for all samples
    if(is.infinite(max(resultssubset$Norm.GRratio.peakdens.1w, na.rm = TRUE)) == FALSE) {
      
      blueline <- NULL
      redline <- NULL
      blueline <- round(mean(resultssubset$Norm.GRratio.peakdens.1w[resultssubset$system.Detail == "All Control Both"], na.rm = TRUE), 2)
      redline <- round(mean(resultssubset$Norm.GRratio.peakdens.1w[resultssubset$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
      
      labeltext <- NULL
      labeltext <- aggregate(Norm.GRratio.peakdens.1w ~ system.Detail, resultssubset, mean)
      labeltext$Norm.GRratio.peakdens.1w <-  paste("Mean: ", round(labeltext$Norm.GRratio.peakdens.1w, 0), "%", sep = "")
      
      labelpos <- NULL
      labelpos <- aggregate(Norm.GRratio.peakdens.1w ~ system.Detail, resultssubset, max)
      labeltext$labelpos <- round(labelpos$Norm.GRratio.peakdens.1w, 2)
      
      plotstore <- NULL
      plotstore <- ggplot(data = resultssubset, aes(x = Norm.GRratio.peakdens.1w, y = system.Detail)) +
        
        geom_boxplot(fill = object.details.violin.fill, width = object.details.violin.width, na.rm = TRUE) +
        
        coord_cartesian(xlim =c(-15, 115)) +
        
        labs(title = "Peak value of Expression Ratio; Grouped by sample types",
             x = object.details.xaxis.label, y = object.details.yaxis.label) +
        
        theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1)) +
        
        geom_point(size = object.details.points.size, color = object.details.points.color, shape = object.details.points.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "top.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color, shape = object.details.topwells.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "bottom.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color,
                   shape = object.details.bottomwells.shape) +
        
        stat_summary(fun = mean, na.rm = TRUE, geom = "point", size = object.details.data.size,
                     color = object.details.data.color, shape = object.details.data.shape) +
        
        geom_text(data = labeltext, aes(x = labelpos + 10, label = Norm.GRratio.peakdens.1w), col = object.details.text.color) +
        
        geom_vline(xintercept = blueline, col = control.max.line.color, lwd = control.min.line.width,
                   show.legend = TRUE, lty = control.min.line.type) +
        
        geom_vline(xintercept = redline, col = control.min.line.color, lwd = control.min.line.width,
                   show.legend = TRUE, lty = control.min.line.type) +
        
        guides(colour = guide_legend(title = "Sample Set")) + theme(legend.position = "none") +
        
        annotate(geom = "text", x = blueline + 10, srt = 90,
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 label = paste("Control: Tandem mRSP-eGFP Present.\nValue:", round(blueline, 2)), col = control.max.text.color) +
        
        annotate(geom = "text", x = redline - 10,
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 label = paste("Control: Only mRSP Present.\nValue:", round(redline, 2)), srt = 90, col = control.min.text.color)
      
      ggsave(plot = plotstore, device = "pdf", width = smallpdfwidth, height = smallpdfheight, units = "in", limitsize = FALSE,
             filename = paste(subdirectory, pdfpath, read.text, " - Plot 6 - Peak Expression (Samples).pdf", sep = ""))
      
    }
    
    ## Plot 7 - Box-plot of average of expression ratio for all samples
    if(is.infinite(max(resultssubset$Norm.GRratio.intgfirst.1w, na.rm = TRUE)) == FALSE) {
      
      blueline <- NULL
      redline <- NULL
      blueline <- round(mean(resultssubset$Norm.GRratio.g2rfirst.1w[resultssubset$system.Detail == "All Control Both"], na.rm = TRUE), 2)
      redline <- round(mean(resultssubset$Norm.GRratio.g2rfirst.1w[resultssubset$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
      
      labeltext <- NULL
      labeltext <- aggregate(Norm.GRratio.g2rfirst.1w ~ system.Detail, resultssubset, mean)
      labeltext$Norm.GRratio.g2rfirst.1w <- paste("Mean: ", round(labeltext$Norm.GRratio.g2rfirst.1w, 0), "%", sep = "")
      
      labelpos <- NULL
      labelpos <- aggregate(Norm.GRratio.g2rfirst.1w ~ system.Detail, resultssubset, max)
      labeltext$labelpos <- round(labelpos$Norm.GRratio.g2rfirst.1w, 2)
      
      plotstore <- NULL
      
      plotstore <-
        ggplot(data = resultssubset, aes(x = Norm.GRratio.g2rfirst.1w, y = system.Detail)) +
        
        geom_boxplot(fill = object.details.violin.fill, width = object.details.violin.width, na.rm = TRUE) +
        
        coord_cartesian(xlim =c(-15, 115)) +
        
        labs(title = "Average of Expression Ratio; Grouped by sample types",
             x = object.details.xaxis.label, y = object.details.yaxis.label) +
        
        theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1)) +
        
        geom_point(size = object.details.points.size, color = object.details.points.color, shape = object.details.points.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "top.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color,
                   shape = object.details.topwells.shape) +
        
        geom_point(data = subset(x = resultssubset, subset = resultssubset$bottom.or.top == "bottom.well"),
                   size = object.details.points.size * 1.5, color = object.details.welldetail.color,
                   shape = object.details.bottomwells.shape) +
        
        stat_summary(fun = mean, na.rm = TRUE, geom = "point", size = object.details.data.size,
                     color = object.details.data.color, shape = object.details.data.shape) +
        
        geom_text(data = labeltext, aes(x = labelpos + 10, label = Norm.GRratio.g2rfirst.1w), col = object.details.text.color) +
        
        geom_vline(xintercept = blueline, col = control.max.line.color,
                   lwd = control.min.line.width, show.legend = TRUE, lty = control.min.line.type) +
        
        geom_vline(xintercept = redline, col = control.min.line.color,
                   lwd = control.min.line.width, show.legend = TRUE, lty = control.min.line.type) +
        
        guides(colour = guide_legend(title = "Sample Set")) + theme(legend.position = "none") +
        
        annotate(geom = "text", x = blueline + 10, srt = 90, col = control.max.text.color, 
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 label = paste("Control: Tandem mRSP-eGFP Present.\nValue:", round(blueline, 2))) +
        
        annotate(geom = "text", label = paste("Control: Only mRSP Present.\nValue:", round(redline, 2)), x = redline - 10,
                 y = levels(resultssubset$system.Detail)[as.integer(length(levels(resultssubset$system.Detail)))/2],
                 srt = 90, col = control.min.text.color)
      
      ggsave(plot = plotstore, device = "pdf", width = smallpdfwidth, height = smallpdfheight, units = "in", limitsize = FALSE,
             filename = paste(subdirectory, pdfpath, read.text, " - Plot 7 - Avg Expression (Samples).pdf", sep = ""))
      
    }
    rm(plotstore)
    rm(labeltext)
    rm(labelpos)
    rm(plottingsubset)
    
  }
  rm(cpdata)
  
}

# Writing allcpdata the data and cleaning up
cat("Writing all 'cpdata'.\nThis will take few minutes (or few hours). Please wait..........\n")

write.csv(allcpdata, file = paste(generatedfilesfolder, "allcpdata (Analysis started at ",
                                  runtime, ").csv", sep = ""), na = "NA", row.names = FALSE, quote = FALSE)

# Turn on warnings globally again
options(warn = 0)

cat("Script for CellProfiler Output Processing is completed\n")