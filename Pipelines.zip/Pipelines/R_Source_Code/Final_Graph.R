rm(list = ls())

## Path where all the supplementary scripts are present.
sourcecode.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Final_Data/Pipelines/R_Source_Code/"

source(file = paste(sep = "", sourcecode.path, "00. Install and Load Packages.R"))

## Image Analysis - Load Scripts and Define Common Parameters
if(0 == 1) {  
  
  cpanalysis.results.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Login19_Process/"
  sscp.pl11.path <- paste(cpanalysis.results.path, "SSCP-PL11/", sep = "")
  data.folder <- "Analysis Generated Files/"
  final.result.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Thesis_Results/"
  
}

## Endpoint Fluorescence Analysis - Load Scripts and Define Common Parameters
if(0 == 1) {
  
  endflu.results.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Login19_Process/"
  final.result.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Thesis_Results/Endpoint_Fluorescence_Analysis/"
  
}

if(!exists("final.result.path")) {
  
  cat("\n\nCAUTION!! Commands should be manually executed. Script will exit.\n\n")
  exit()
  
}

############################################################
############################################################
############################################################

## Image Analysis

############################################################
############################################################

## EXP-2022-03-23
{
  
  ## EXP-220323 - Heatmap of Two-Site Incorporation - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "Two-Site Incorporation - Complete"
      plot.title <- "Normalized Expression Ratio - Two Stop Codons in eGFP"
      plot.subtitle <- "(Both G.C.E. Systems Present in Wells)"
      y.axis.title <- "G.C.E. Systems Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 5 and 6 contain two-site complete data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 5" | all.experiment.data$platename == "Plate 6")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$Position.2, " (", plotdata.without.control$Codon.2, ")", sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$Original.AA.2,
                                                      as.integer(substr(plotdata.without.control$Position.2, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.2, sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UCAP.2, " + ",
                                                              plotdata.without.control$UAA.1, " + ", plotdata.without.control$UAA.2, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1," (tRNA-", plotdata.without.control$Anticodon.1, ") and\n",
                                                      plotdata.without.control$RS.2," (tRNA-", plotdata.without.control$Anticodon.2, ") with\n ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ") and ",
                                                      plotdata.without.control$UAA.2, " (", plotdata.without.control$Conc.2, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of Two-Site Incorporation - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "Two Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - Two Stop Codons in eGFP"
      plot.subtitle <- "(Complete System - All Components Present)"
      y.axis.title <- "Stop Codon Sites, G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 10
      
      # Only plate 5 and 6 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 5" | all.experiment.data$platename == "Plate 6")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UCAP.2, " + ",
                                                              plotdata.without.control$UAA.1, " + ", plotdata.without.control$UAA.2, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$Position.2, " (", plotdata.without.control$Codon.2, ")",
                                                              sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and ",
                                                      plotdata.without.control$Original.AA.2,
                                                      as.integer(substr(plotdata.without.control$Position.2, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.2, "\n",
                                                      plotdata.without.control$RS.1, " (", plotdata.without.control$Anticodon.1, ") + ",
                                                      plotdata.without.control$RS.2, " (", plotdata.without.control$Anticodon.2, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,") + ",
                                                      plotdata.without.control$UAA.2, " (", plotdata.without.control$Conc.2, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(system.UCAP.all ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste("Mean Value = ",
                                             round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), "  ",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = system.UCAP.all), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = system.UCAP.all), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = system.UCAP.all), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 50, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 75, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 75, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 6, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plotdata.after.cutoff$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 6, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = error.bar.max + 25, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 6, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323 - Heatmap of Two-Site - One UAA
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "Two-Stop Codons, One UAA"
      plot.title <- "Normalized Expression Ratio - Two Stop Codons in eGFP"
      plot.subtitle <- "(Both G.C.E. Systems Present in Wells, Only One UAA Present)"
      y.axis.title <- "G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 3 and 4 contain data for two-site one UAA. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 3" | all.experiment.data$platename == "Plate 4")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$Position.2, " (", plotdata.without.control$Codon.2, ")", sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$Original.AA.2,
                                                      as.integer(substr(plotdata.without.control$Position.2, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.2, sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UCAP.2, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") and\n",
                                                      plotdata.without.control$RS.2, " (tRNA-", plotdata.without.control$Anticodon.2, ") with\n ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 7, height = 14, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 7, height = 14, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 7, height = 14, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of Two-Site - One UAA
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "Two Stop Codon - One UAA"
      plot.title <- "Normalized Expression Ratio - Two Stop Codons in eGFP"
      plot.subtitle <- "(Only One UAA Present)"
      y.axis.title <- "Stop Codon Sites, G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 0.75
      
      # Only plate 3 and 4 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 3" | all.experiment.data$platename == "Plate 4")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UCAP.2, " + ",
                                                              plotdata.without.control$UAA.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$Position.2, " (", plotdata.without.control$Codon.2, ")",
                                                              sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and ",
                                                      plotdata.without.control$Original.AA.2,
                                                      as.integer(substr(plotdata.without.control$Position.2, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.2, "\n",
                                                      plotdata.without.control$RS.1, " (", plotdata.without.control$Anticodon.1, ") + ",
                                                      plotdata.without.control$RS.2, " (", plotdata.without.control$Anticodon.2, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(system.UCAP.all ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste("Mean Value = ",
                                             round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), "  ",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = system.UCAP.all), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = system.UCAP.all), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = system.UCAP.all), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 50, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 75, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 75, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = error.bar.max + 25, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323 - Heatmap of One-Site - tRNA Mismatch
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - tRNA Mismatch"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(tRNA Mismatch Between G.C.E. and P.O.I.)"
      y.axis.title <- "G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 1 and 2 contain data for Incorrect tRNA. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data,
                                        all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data,
                                        useful.shortlisted.data$read.time == "Read 2\t72 Hours" & useful.shortlisted.data$sample.type == "Incorrect tRNA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1, " ",
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ")\n with ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 9, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 9, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 9, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of One-Site - tRNA Mismatch
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Incorrect tRNA"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(tRNA mismatch between G.C.E. and P.O.I.)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 0.25
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set == "All Control" |
                                          useful.shortlisted.data$sample.type == "Incorrect tRNA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(system.UCAP.all ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste("Mean Value = ",
                                             round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), "  ",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = system.UCAP.all), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = system.UCAP.all), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = system.UCAP.all), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 7, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 7, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = error.bar.max + 25, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 7, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323 - Heatmap of One-Site - tRNA and UAA Mismatch
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - tRNA and UAA Mismatch"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(tRNA and UAA Mismatch Between G.C.E. and P.O.I.)"
      y.axis.title <- "G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data,
                                        all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data,
                                        useful.shortlisted.data$read.time == "Read 2\t72 Hours" & useful.shortlisted.data$sample.type == "Incorrect tRNA and UAA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1, " ",
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ")\n with ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 13, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 13, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 13, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of One-Site - tRNA and UAA Mismatch
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Incorrect tRNA and UAA"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(tRNA and UAA mismatch between G.C.E. and P.O.I.)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 0.25
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set == "All Control" |
                                          useful.shortlisted.data$sample.type == "Incorrect tRNA and UAA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(system.UCAP.all ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste("Mean Value = ",
                                             round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), "  ",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = system.UCAP.all), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = system.UCAP.all), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = system.UCAP.all), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = error.bar.max + 25, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323 - Heatmap of One-Site - Incorrect UAA
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - UAA Mismatch"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(UAA Mismatch with G.C.E.)"
      y.axis.title <- "G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data,
                                        all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data,
                                        useful.shortlisted.data$read.time == "Read 2\t72 Hours" & useful.shortlisted.data$sample.type == "Incorrect UAA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, " + ",
                                                              plotdata.without.control$Codon.1, sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$RS.1, " + ", plotdata.without.control$UAA.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, "\n with ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 6, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 6, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 6, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of One-Site - Incorrect UAA
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Incorrect UAA"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Incorrect UAA Present in System)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 1
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set == "All Control" |
                                          useful.shortlisted.data$sample.type == "Incorrect UAA")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(system.UCAP.all ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste("Mean Value = ",
                                             round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), "  ",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = system.UCAP.all), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = system.UCAP.all), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = system.UCAP.all), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = error.bar.max + 25, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323 - Heatmap of One-Site - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Complete System - All Components Present)"
      y.axis.title <- "G.C.E. Systems and UAA Present in Well\n"
      x.axis.title <- "\nPositions of Stop Codons"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data,
                                        all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data,
                                        useful.shortlisted.data$read.time == "Read 2\t72 Hours" & useful.shortlisted.data$sample.type == "One Site Complete")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (", plotdata.without.control$Anticodon.1, "-tRNA)\n with ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
        }
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- final.plot.label$graph.label[,1]
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$X.Axis.Text <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        # Assign Text values for X-Axis and Y-Axis in final.plot.label 
        if(0 == 1) {
          
          for(i in 1:len.x) {
            final.plot.label$X.Axis.Text[final.plot.label$X.Axis.Text.Sorting == all.x.sorting.levels[i]] <-
              plot.axis.rename.x.axis$X.Axis.Text[plot.axis.rename.x.axis$X.Axis.Text.Sorting == all.x.sorting.levels[i]]
          }
          for(i in 1:len.y) {
            final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
              plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]]
          }
          
        }
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE, aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = graph.label,
                                                                               fill = graph.label, label = graph.text)) +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(
            plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
            plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
            axis.text.x = element_text(angle = 90)) +
          
          labs(
            title = plot.title,
            subtitle = plot.subtitle,
            y = y.axis.title,
            x = x.axis.title,
            fill = fill.title.legend) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
        
        # Save the plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 7, units = "in", limitsize = FALSE)
        
        # Modify the values on X-Axis and Y-Axis
        plotstore <- plotstore + scale_x_discrete(label = plot.axis.rename.x.axis$X.Axis.Text) + scale_y_discrete(label = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 7, units = "in", limitsize = FALSE)
        
        # Add the text on the plotstore
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3)
        
        # Save the new plot as PDF
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 5, height = 7, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title.legend)
        
      }
      
    }
    
  }
  ## EXP-220323 - Boxplot and Barplot of One-Site - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "220323_Two_Site_Incorporation/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "220323_004207_Plates1-8_BS384FlrImgAna4Expo_1_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-08 16-39-32).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Complete System in Wells)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" | all.experiment.data$platename == "Plate 2")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 2\t72 Hours")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set == "All Control" |
                                          useful.shortlisted.data$sample.type == "One Site Complete")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UAA.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), "\n± ",
                                             round(final.plot.label$graph.label[,2],2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1],2), " ± ",
                                             round(final.plot.label$graph.label[,2],2), " \n",
                                             "(N = ", final.plot.label$graph.label[,3], ")", sep = "")
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1],2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2],2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        # graph.label column contains values for plotting the intensity.
        final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(color = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 15, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 15, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 5, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.5) +
          
          geom_errorbar(aes(xmin = error.bar.min, xmax = error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = 12, label = graph.text), col = rgb(0,0,0,1))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
}

############################################################
############################################################

## EXP-2021-05-30 and 2021-06-05
{
  
  ## EXP-210530_210605 - Boxplot and Barplot of One-Site Incorporation - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "210530_210605_One_Site_Screening/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "210530_210605_Manual_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-14 13-48-26).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Complete System in Wells)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Samples\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 30
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"]," + ",
                                                                                                         plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], " (",
                                                                                                         plotdata.without.control$Codon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1," + ",
                                                               plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ")", sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        plotdata.without.control$Y.Axis.Text[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$Original.AA.1[plotdata.without.control$UAA.1 == "NoUAA"],
                                                                                                 as.integer(substr(plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], start = 2, stop = 4)),
                                                                                                 plotdata.without.control$Codon.1[plotdata.without.control$UAA.1 == "NoUAA"], " and\n",
                                                                                                 plotdata.without.control$RS.1[plotdata.without.control$UAA.1 == "NoUAA"], " (tRNA-",
                                                                                                 plotdata.without.control$Anticodon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$sample.set == "Complete")
        
        plotdata.without.control$nouaa.well.row <- plotdata.background$well.row
        plotdata.without.control$nouaa.well.column <- plotdata.background$well.column
        plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w <- plotdata.background$Norm.GRratio.intgfirst.1w
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        plotdata.without.control$row.check <- as.integer(plotdata.without.control$well.row) - as.integer(plotdata.without.control$nouaa.well.row) + 1
        if(FALSE %in% (plotdata.without.control$row.check == 0)) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ Y.Axis.Text.Sorting, plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), " ± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        # graph.label column contains values for plotting the intensity.
        # final.plot.label$graph.label <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(x = nouaa.Norm.GRratio.intgfirst.1w), width = 0.70, na.rm = TRUE,
                       varwidth = FALSE, fatten = 1.5, outlier.shape = NA, col = rgb(0.25,0.25,0.25,0.25), alpha = 0.5) +
          
          geom_point(aes(x = nouaa.Norm.GRratio.intgfirst.1w), size = 2, pch = 18, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          geom_boxplot(aes(color = RS.1, fill = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 200, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 200, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 5, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 225, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$bgrd.corrected.mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = bgrd.corrected.mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          #geom_boxplot(aes(color = colour.class), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.75) +
          
          geom_errorbar(aes(xmin = bgrd.corrected.error.bar.min, xmax = bgrd.corrected.error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 10, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plotdata.after.cutoff$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 15, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = 13, label = graph.text), col = rgb(0,0,0,1), size = 6)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-210530_210605 - Heatmap of One-Site Incorporation - Complete
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "210530_210605_One_Site_Screening/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "210530_210605_Manual_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-14 13-48-26).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- ""
      y.axis.title <- "G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nPosition on eGFP and Original Amino Acid"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Only plate 1 and 2 contain this data. Furthermore, we are interested only in the final read (Read 2)
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$read.time == "Read 2\t72 Hours")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"], sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") + ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        plotdata.without.control$Y.Axis.Text[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$RS.1[plotdata.without.control$UAA.1 == "NoUAA"], " (tRNA-",
                                                                                                 plotdata.without.control$Anticodon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, sep = "")
        
        # X.Axis.Text is final representation on Y-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)), sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$sample.set == "Complete")
        
        plotdata.without.control$nouaa.well.row <- plotdata.background$well.row
        plotdata.without.control$nouaa.well.column <- plotdata.background$well.column
        plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w <- plotdata.background$Norm.GRratio.intgfirst.1w
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        plotdata.without.control$row.check <- as.integer(plotdata.without.control$well.row) - as.integer(plotdata.without.control$nouaa.well.row) + 1
        if(FALSE %in% (plotdata.without.control$row.check == 0)) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$background.text <- paste(final.plot.label$background.mean.values, "\n± ", final.plot.label$background.error.values, sep = "")
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), "\n± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = default.mean.values,
                                fill = default.mean.values, label = default.mean.values)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = background.mean.values,
                                fill = background.mean.values, label = background.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background Corrected"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = bgrd.corrected.mean.values,
                                fill = bgrd.corrected.mean.values, label = graph.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-210530_210605 - Proposed Heatmap of Two Site Incorporation
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "210530_210605_One_Site_Screening/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "210530_210605_Manual_Cropped_CentreCommon/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-14 13-48-26).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    # defines range
    upperend <- 100
    cutoff.value <- 5
    
    # All TAG data
    tag.data <- subset(all.experiment.data, all.experiment.data$Codon.1 == "TAG" &
                         all.experiment.data$system.UAA != "NoUAA" &
                         all.experiment.data$read.time == "Read 2\t72 Hours" &
                         all.experiment.data$RS.1 != "MbPyl-RS" &
                         all.experiment.data$RS.1 != "DanAla-RS" &
                         all.experiment.data$RS.1 != "EcTrpH9-RS" &
                         all.experiment.data$RS.1 != "EcTrpH14-RS")
    
    tag.data.summary <- aggregate(data = tag.data, Norm.GRratio.intgfirst.1w  ~ Position.1 + Original.AA.1 + UAA.1 + Codon.1, mean)
    
    colnames(tag.data.summary) <- c("Position", "Original.AA", "UAA", "Codon", "NER")
    
    tag.data.summary <- subset(tag.data.summary, tag.data.summary$Position == "P039" |
                                 tag.data.summary$Position == "P052" |
                                 tag.data.summary$Position == "P099" |
                                 tag.data.summary$Position == "P176" |
                                 tag.data.summary$Position == "P204")
    
    tag.data.summary$Mutation <- paste(tag.data.summary$Original.AA,
                                       as.integer(substr(tag.data.summary$Position, start = 2, stop = 4)),
                                       tag.data.summary$Codon, sep = "")
    
    # All TGA data
    tga.data <- subset(all.experiment.data, all.experiment.data$Codon.1 == "TGA" &
                         all.experiment.data$system.UAA != "NoUAA" &
                         all.experiment.data$read.time == "Read 2\t72 Hours" &
                         all.experiment.data$RS.1 != "MbPyl-RS" &
                         all.experiment.data$RS.1 != "DanAla-RS" &
                         all.experiment.data$RS.1 != "EcTrpH9-RS" &
                         all.experiment.data$RS.1 != "EcTrpH14-RS")
    
    tga.data.summary <- aggregate(data = tga.data, Norm.GRratio.intgfirst.1w  ~ Position.1 + Original.AA.1 + UAA.1 + Codon.1, mean)
    
    colnames(tga.data.summary) <- c("Position", "Original.AA", "UAA", "Codon", "NER")
    
    tga.data.summary <- subset(tga.data.summary, tga.data.summary$Position == "P039" |
                                 tga.data.summary$Position == "P052" |
                                 tga.data.summary$Position == "P099" |
                                 tga.data.summary$Position == "P176" |
                                 tga.data.summary$Position == "P204")
    
    tga.data.summary$Mutation <- paste(tga.data.summary$Original.AA,
                                       as.integer(substr(tga.data.summary$Position, start = 2, stop = 4)),
                                       tga.data.summary$Codon, sep = "")
    
    data.predict <- data.frame(Mutation.1 = as.character(),
                               Position.1 = as.character(),
                               UAA.1 = as.character(),
                               Mutation.2 = as.character(),
                               Position.2 = as.character(),
                               UAA.2 = as.character(),
                               Construct = as.character(),
                               NER.1 = as.numeric(),
                               NER.2 = as.numeric(),
                               Predicted.NER = as.numeric())
    
    temp.data.predict <- data.frame(Mutation.1 = as.character(NA),
                                    Position.1 = as.character(NA),
                                    UAA.1 = as.character(NA),
                                    Mutation.2 = as.character(NA),
                                    Position.2 = as.character(NA),
                                    UAA.2 = as.character(NA),
                                    Construct = as.character(NA),
                                    NER.1 = as.numeric(NA),
                                    NER.2 = as.numeric(NA),
                                    Predicted.NER = as.numeric(NA))
    
    for(i in 1:length(tag.data.summary$Codon)) {
      
      for(j in 1:length(tga.data.summary$Codon)) {
        
        temp.data.predict$Mutation.1 <- tag.data.summary$Mutation[i]
        temp.data.predict$Position.1 <- tag.data.summary$Position[i]
        temp.data.predict$UAA.1 <- tag.data.summary$UAA[i]
        temp.data.predict$Mutation.2 <- tga.data.summary$Mutation[j]
        temp.data.predict$Position.2 <- tga.data.summary$Position[j]
        temp.data.predict$UAA.2 <- tga.data.summary$UAA[j]
        temp.data.predict$Construct <- paste(tag.data.summary$Mutation[i], " and\n", tga.data.summary$Mutation[j], sep = "")
        temp.data.predict$NER.1 <- tag.data.summary$NER[i]
        temp.data.predict$NER.2 <- tga.data.summary$NER[j]
        temp.data.predict$Predicted.NER <- tag.data.summary$NER[i]*tga.data.summary$NER[j]/100
        
        data.predict <- rbind(data.predict, temp.data.predict)
        
      }
      
    }
    
    data.predict$All.UAA <- paste(data.predict$UAA.1, data.predict$UAA.2, sep = " + ")
    
    debug.data.predict <- data.predict
    
    data.predict <- subset(data.predict, data.predict$Position.1 != data.predict$Position.2 &
                             data.predict$UAA.1 != data.predict$UAA.2 &
                             as.integer(substr(data.predict$Position.1, start = 2, stop = 4)) < as.integer(substr(data.predict$Position.2, start = 2, stop = 4)))
    
    data.predict <- subset(data.predict, data.predict$UAA.1 != "AzPhe" | data.predict$UAA.2 != "PrPhe")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "PrPhe" | data.predict$UAA.2 != "AzPhe")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "N3Lys" | data.predict$UAA.2 != "PrLys")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "PrLys" | data.predict$UAA.2 != "N3Lys")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "AzPhe" | data.predict$UAA.2 != "N3Lys")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "N3Lys" | data.predict$UAA.2 != "AzPhe")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "PrLys" | data.predict$UAA.2 != "PrPhe")
    data.predict <- subset(data.predict, data.predict$UAA.1 != "PrPhe" | data.predict$UAA.2 != "PrLys")
    
    data.predict$Y.Axis.Order <- NA
    
    data.predict$Y.Axis.Order[data.predict$All.UAA == "ANAP + AzPhe"] <- "01"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "ANAP + N3Lys"] <- "03"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "ANAP + PrLys"] <- "04"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "ANAP + PrPhe"] <- "02"
    
    data.predict$Y.Axis.Order[data.predict$All.UAA == "AzPhe + ANAP"] <- "05"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "AzPhe + PrLys"] <- "07"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "N3Lys + ANAP"] <- "09"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "N3Lys + PrPhe"] <- "11"
    
    data.predict$Y.Axis.Order[data.predict$All.UAA == "PrLys + ANAP"] <- "10"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "PrLys + AzPhe"] <- "12"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "PrPhe + ANAP"] <- "06"
    data.predict$Y.Axis.Order[data.predict$All.UAA == "PrPhe + N3Lys"] <- "08"
    
    data.predict$Y.Axis <- paste(data.predict$Y.Axis.Order, data.predict$All.UAA, sep = " ")
    
    data.predict$X.Axis.Order <- NA
    
    data.predict$X.Axis.Order[data.predict$Construct == "TYR39TAG and\nLYS52TGA"] <- "01"
    data.predict$X.Axis.Order[data.predict$Construct == "TYR39TAG and\nPHE99TGA"] <- "02"
    data.predict$X.Axis.Order[data.predict$Construct == "TYR39TAG and\nVAL176TGA"] <- "03"
    data.predict$X.Axis.Order[data.predict$Construct == "TYR39TAG and\nGLN204TGA"] <- "04"

    data.predict$X.Axis.Order[data.predict$Construct == "LYS52TAG and\nPHE99TGA"] <- "05"
    data.predict$X.Axis.Order[data.predict$Construct == "LYS52TAG and\nVAL176TGA"] <- "06"
    data.predict$X.Axis.Order[data.predict$Construct == "LYS52TAG and\nGLN204TGA"] <- "07"

    data.predict$X.Axis.Order[data.predict$Construct == "PHE99TAG and\nVAL176TGA"] <- "08"
    data.predict$X.Axis.Order[data.predict$Construct == "PHE99TAG and\nGLN204TGA"] <- "09"

    data.predict$X.Axis.Order[data.predict$Construct == "VAL176TAG and\nGLN204TGA"] <- "10"
    
    data.predict$X.Axis <- paste(data.predict$X.Axis.Order, data.predict$Construct, sep = " ")
    
    data.predict$Predicted.NER <- round(data.predict$Predicted.NER, 2)
    
    plotstore <- ggplot(data = data.predict, na.rm = TRUE, aes(x = X.Axis, y = Y.Axis, z = Predicted.NER,
                                                                           fill = Predicted.NER, label = Predicted.NER)) +
      
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      
      theme(
        plot.title = element_text(color = "Blue", size = 12, face = "bold", hjust = 0.5),
        plot.subtitle = element_text(color = "Red", size = 12, face = "bold", hjust = 0.5),
        axis.text.x = element_text(angle = 90)) +
      
      labs(
        title = "Predicted Two-Site Incorporation NER",
        subtitle = "Predicted from One Site UAA Incorporation Screening",
        y = "G.C.E. Systems",
        x = "Mutations",
        fill = "Normalized \nExpression \nRatio") +
      
      geom_tile(data = data.predict, na.rm = TRUE) +
      
      scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red")
    
    # Save the plot as PDF
    ggsave(plot = plotstore,
           filename = "Predicted NER values for two UAA Incorporation.pdf",  
           device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
    
    # Add the text on the plotstore
    plotstore <- plotstore + geom_text(size = 3)
    
    # Save the new plot as PDF
    ggsave(plot = plotstore,
           filename = "Predicted NER values for two UAA Incorporation (with labels).pdf",  
           device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
  
  }
  
}

############################################################
############################################################

## EXP-2020-08-13
{
  
  ## EXP-200813 - Boxplot and Barplot of UCAP G.C.E. Systems for Position 39 on eGFP
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200813_115245_Ratios/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200813_115245_Image Analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 20-42-59).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Complete System in Wells)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Sample\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$read.time == "Read 4\t72 Hours" &
                                          all.experiment.data$sample.set != "tRNA Mismatch" &
                                          all.experiment.data$platename != "Plate 5" &
                                          all.experiment.data$platename != "Plate 10" &
                                          all.experiment.data$platename != "Plate 11" &
                                          all.experiment.data$platename != "Plate 12" &
                                          all.experiment.data$platename != "Plate 13" &
                                          all.experiment.data$UCAP.1 != "pMbPyl" &
                                          all.experiment.data$UCAP.1 != "pANAP")
      
      # Delete the following segment if necessary - it is for plotting the comparison of U.A.A. Concentrations
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$RS.1 != "ANAP-RS" &
                                          useful.shortlisted.data$RS.1 != "EcTrp-H14-RS" &
                                          useful.shortlisted.data$RS.1 != "EcTrp-H9-RS" &
                                          useful.shortlisted.data$RS.1 != "MbPyl-RS")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"]," + ",
                                                                                                         plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], " (",
                                                                                                         plotdata.without.control$Codon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1," + ",
                                                               plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ")", sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") with\n",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        plotdata.without.control$Y.Axis.Text[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$Original.AA.1[plotdata.without.control$UAA.1 == "NoUAA"],
                                                                                                 as.integer(substr(plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], start = 2, stop = 4)),
                                                                                                 plotdata.without.control$Codon.1[plotdata.without.control$UAA.1 == "NoUAA"], " and\n",
                                                                                                 plotdata.without.control$RS.1[plotdata.without.control$UAA.1 == "NoUAA"], " (tRNA-",
                                                                                                 plotdata.without.control$Anticodon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$Norm.GRratio.intgfirst.1w[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), " ± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(x = nouaa.Norm.GRratio.intgfirst.1w), width = 0.70, na.rm = TRUE,
                       varwidth = FALSE, fatten = 1.5, outlier.shape = NA, col = rgb(0.25,0.25,0.25,0.25), alpha = 0.5) +
          
          geom_point(aes(x = nouaa.Norm.GRratio.intgfirst.1w), size = 2, pch = 18, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          geom_boxplot(aes(color = RS.1, fill = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 5, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 20, height = 20, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.graph.type <- "Barplot with Error Bars"
        
        plotdata.after.cutoff <- subset(final.plot.label, final.plot.label$bgrd.corrected.mean.values >= cutoff.value)
        
        control.text.height.cutoff <- levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.after.cutoff$Y.Axis.Text.Sorting)))))/2]
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.after.cutoff, aes(x = bgrd.corrected.mean.values, y = Y.Axis.Text.Sorting, labels = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height.cutoff,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_bar(aes(fill = colour.class), width = 0.70, stat = "Identity", color = "black", alpha = 0.75) +
          
          geom_errorbar(aes(xmin = bgrd.corrected.error.bar.min, xmax = bgrd.corrected.error.bar.max), width = 0.3, position = position_dodge(0.9), color = rgb(0,0,0,0.5)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = paste(plot.subtitle, "\tCutoff = ", cutoff.value, "%",sep = ""),
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 5, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 5, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(aes(x = 10, label = graph.text), col = rgb(0,0,0,1))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 5, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-200813 - Boxplot of Expression Ratio for various ratios of UCAP and UAT
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200813_115245_Ratios/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200813_115245_Image Analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 20-42-59).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "Expression Ratio Comparison"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- "(Complete System in Wells)"
      y.axis.title <- "Stop Codon Position, G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nNormalized Expression Ratio"
      fill.title.legend <- "Sample\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 11" | all.experiment.data$platename == "Plate 12")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 4\t72 Hours")
      
      {
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (1 ul)"] <- "UCAP.03 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (2 ul)"] <- "UCAP.03 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (3 ul)"] <- "UCAP.03 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (4 ul)"] <- "UCAP.03 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (5 ul)"] <- "UCAP.03 (2.5 ul)"
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (1 ul)"] <- "UCAP.21 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (2 ul)"] <- "UCAP.21 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (3 ul)"] <- "UCAP.21 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (4 ul)"] <- "UCAP.21 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (5 ul)"] <- "UCAP.21 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (1 ul)"] <- "UTX1.06 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (2 ul)"] <- "UTX1.06 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (3 ul)"] <- "UTX1.06 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (4 ul)"] <- "UTX1.06 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (5 ul)"] <- "UTX1.06 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (1 ul)"] <- "UTX1.05 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (2 ul)"] <- "UTX1.05 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (3 ul)"] <- "UTX1.05 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (4 ul)"] <- "UTX1.05 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (5 ul)"] <- "UTX1.05 (2.5 ul)"
        
      }
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$Position.1, " + ", plotdata.without.control$POI.Name.1, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"]," + ",
                                                                                                         plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], " (",
                                                                                                         plotdata.without.control$POI.Name.1[plotdata.without.control$POI.Name.1 == "NoUAA"], ")", sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1," + ",
                                                               plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ")", sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$UCAP.1, " +\n",
                                                      plotdata.without.control$POI.Name.1, " with\n",
                                                      plotdata.without.control$UAA.1, sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$Norm.GRratio.intgfirst.1w[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round Norm.GRratio.intgfirst.1w to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$Norm.GRratio.intgfirst.1w, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.Norm.GRratio.intgfirst.1w, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), " ± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = Norm.GRratio.intgfirst.1w, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          annotate(geom = "text", x = blueline + blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Tandem mRSP and eGFP Present.\n",
                                 "Expression Ratio: ", blueline, "\n",sep = ""),
                   srt = 90, col = "Blue") +
          
          annotate(geom = "text", x = redline - blueline * 0.05,
                   y = control.text.height,
                   label = paste("\nControl: Only mRSP Present.\n",
                                 "Expression Ratio: ", redline, "\n", sep = ""),
                   srt = 90, col = "Red") +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_vline(xintercept = blueline, col = "Blue", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_vline(xintercept = redline, col = "Red", lwd = 0.2, lty = "dashed", show.legend = TRUE) +
          
          geom_boxplot(aes(x = nouaa.Norm.GRratio.intgfirst.1w), width = 0.70, na.rm = TRUE,
                       varwidth = FALSE, fatten = 1.5, outlier.shape = NA, col = rgb(0.25,0.25,0.25,0.25), alpha = 0.5) +
          
          geom_point(aes(x = nouaa.Norm.GRratio.intgfirst.1w), size = 2, pch = 18, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          geom_boxplot(aes(color = RS.1, fill = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-200813 - Boxplot of eGFP Production for various ratios of UCAP and UAT
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200813_115245_Ratios/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200813_115245_Image Analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 20-42-59).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "eGFP Production"
      plot.title <- "UAA Labelled eGFP Expression"
      plot.subtitle <- "(Complete System in Wells)"
      y.axis.title <- "G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\neGFP Expression (Fluorescence Units)"
      fill.title.legend <- "Sample\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 11" | all.experiment.data$platename == "Plate 12")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 4\t72 Hours")
      
      {
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (1 ul)"] <- "UCAP.03 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (2 ul)"] <- "UCAP.03 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (3 ul)"] <- "UCAP.03 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (4 ul)"] <- "UCAP.03 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (5 ul)"] <- "UCAP.03 (2.5 ul)"
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (1 ul)"] <- "UCAP.21 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (2 ul)"] <- "UCAP.21 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (3 ul)"] <- "UCAP.21 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (4 ul)"] <- "UCAP.21 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (5 ul)"] <- "UCAP.21 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (1 ul)"] <- "UTX1.06 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (2 ul)"] <- "UTX1.06 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (3 ul)"] <- "UTX1.06 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (4 ul)"] <- "UTX1.06 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (5 ul)"] <- "UTX1.06 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (1 ul)"] <- "UTX1.05 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (2 ul)"] <- "UTX1.05 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (3 ul)"] <- "UTX1.05 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (4 ul)"] <- "UTX1.05 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (5 ul)"] <- "UTX1.05 (2.5 ul)"
        
      }
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$Position.1, " + ", plotdata.without.control$POI.Name.1, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"]," + ",
                                                                                                         plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], " (",
                                                                                                         plotdata.without.control$POI.Name.1[plotdata.without.control$POI.Name.1 == "NoUAA"], ")", sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1," + ",
                                                               plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ")", sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$UCAP.1, " +\n",
                                                      plotdata.without.control$POI.Name.1, " with\n",
                                                      plotdata.without.control$UAA.1, sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.grd.sum.objegfp <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          plotdata.without.control$nouaa.grd.sum.objegfp[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$grd.sum.objegfp[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round grd.sum.objegfp to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$grd.sum.objegfp, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.grd.sum.objegfp, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), " ± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = grd.sum.objegfp, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_boxplot(aes(x = nouaa.grd.sum.objegfp), width = 0.70, na.rm = TRUE,
                       varwidth = FALSE, fatten = 1.5, outlier.shape = NA, col = rgb(0.25,0.25,0.25,0.25), alpha = 0.5) +
          
          geom_point(aes(x = nouaa.grd.sum.objegfp), size = 2, pch = 18, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          geom_boxplot(aes(color = RS.1, fill = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-200813 - Boxplot of mRSP Production for various ratios of UCAP and UAT
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200813_115245_Ratios/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200813_115245_Image Analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 20-42-59).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t0 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t20 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t45 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\t71 Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Boxplot"
      pdf.data.subset <- "mRSP Production"
      plot.title <- "WT-mRaspberry Expression"
      plot.subtitle <- ""
      y.axis.title <- "G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nmRaspberry Expression (Fluorescence Units)"
      fill.title.legend <- "Sample\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 11" | all.experiment.data$platename == "Plate 12")
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$read.time == "Read 4\t72 Hours")
      
      {
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (1 ul)"] <- "UCAP.03 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (2 ul)"] <- "UCAP.03 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (3 ul)"] <- "UCAP.03 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (4 ul)"] <- "UCAP.03 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-03 (5 ul)"] <- "UCAP.03 (2.5 ul)"
        
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (1 ul)"] <- "UCAP.21 (0.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (2 ul)"] <- "UCAP.21 (1.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (3 ul)"] <- "UCAP.21 (1.5 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (4 ul)"] <- "UCAP.21 (2.0 ul)"
        useful.shortlisted.data$UCAP.1[useful.shortlisted.data$UCAP.1 == "UCAP-21 (5 ul)"] <- "UCAP.21 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (1 ul)"] <- "UTX1.06 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (2 ul)"] <- "UTX1.06 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (3 ul)"] <- "UTX1.06 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (4 ul)"] <- "UTX1.06 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT04.1 (5 ul)"] <- "UTX1.06 (2.5 ul)"
        
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (1 ul)"] <- "UTX1.05 (0.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (2 ul)"] <- "UTX1.05 (1.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (3 ul)"] <- "UTX1.05 (1.5 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (4 ul)"] <- "UTX1.05 (2.0 ul)"
        useful.shortlisted.data$POI.Name.1[useful.shortlisted.data$POI.Name.1 == "UAT03.1 (5 ul)"] <- "UTX1.05 (2.5 ul)"
        
      }
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$Norm.GRratio.intgfirst.1w[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$Position.1, " + ", plotdata.without.control$POI.Name.1, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"]," + ",
                                                                                                         plotdata.without.control$Position.1[plotdata.without.control$UAA.1 == "NoUAA"], " (",
                                                                                                         plotdata.without.control$POI.Name.1[plotdata.without.control$POI.Name.1 == "NoUAA"], ")", sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1," + ",
                                                               plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ")", sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$UCAP.1, " +\n",
                                                      plotdata.without.control$POI.Name.1, " with\n",
                                                      plotdata.without.control$UAA.1, sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.grd.sum.objmrsp <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          plotdata.without.control$nouaa.grd.sum.objmrsp[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$grd.sum.objmrsp[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          #plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round grd.sum.objmrsp to two decimal places
        {
          #plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          #plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$grd.sum.objmrsp, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.grd.sum.objmrsp, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), " ± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        #all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        #len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        #if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
        #  exit()
        #}
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        final.plot.label$Y.Axis.Text <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
          final.plot.label$Y.Axis.Text[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.rename.y.axis$Y.Axis.Text[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        final.plot.label$Y.Axis.Text <- as.factor(final.plot.label$Y.Axis.Text)
        
        
        #if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
        #  print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
        #  exit()
        #}
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = grd.sum.objmrsp, y = Y.Axis.Text.Sorting)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          guides(colour = guide_legend(title = "Normalized\n Expression\n Ratio")) + theme(legend.position="none") +
          
          geom_boxplot(aes(x = nouaa.grd.sum.objmrsp), width = 0.70, na.rm = TRUE,
                       varwidth = FALSE, fatten = 1.5, outlier.shape = NA, col = rgb(0.25,0.25,0.25,0.25), alpha = 0.5) +
          
          geom_point(aes(x = nouaa.grd.sum.objmrsp), size = 2, pch = 18, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          geom_boxplot(aes(color = RS.1, fill = RS.1), width = 0.70, na.rm = TRUE, varwidth = FALSE, fatten = 1.5, outlier.shape = NA, alpha = 0.5) +
          
          geom_point(aes(color = RS.1), size = 2, pch = 18, na.rm = TRUE) +
          
          stat_summary(aes(color = RS.1), fun = mean, geom = "point", shape = 15, size = 3, na.rm = TRUE) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, aes(x = graph.labeldist + 10, label = graph.text), col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 8, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
}

############################################################
############################################################

## EXP-2020-07-05
{
  
  ## EXP-200705 - Kinetics of eGFP Production for Most Prominent RS (change as needed by other systems)
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200705_093441_Kinetics/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200705_093441_Image acquisition and analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 19-55-19).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t19 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t44 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t66 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\tNA Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t19 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t44 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t66 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\tNA Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    # defines range
    upperend <- 100
    cutoff.value <- 25
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Kinetics"
      pdf.data.subset <- "eGFP Production (Only Prominent)"
      plot.title <- "eGFP Production Over Time"
      plot.subtitle <- ""
      y.axis.title <- "eGFP Produced (Fluorescence Units)\n"
      x.axis.title <- "\nRead Time (Hours)"
      fill.title.legend <- "Sample\n"
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" |
                                          all.experiment.data$platename == "Plate 4" |
                                          all.experiment.data$platename == "Plate 8" |
                                          all.experiment.data$platename == "Plate 20" ) # Plate 20 is here as a nonsense value
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$UCAP.1 != "NoUCAP")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (", plotdata.without.control$UAA.1, ")", sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column, plotdata.background$read.time,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column, plotdata.without.control$read.time,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.plot.parameter <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          #################################### Correct This ##############################
          plotdata.without.control$nouaa.plot.parameter[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$grd.sum.objegfp[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # Convert chr to factor and round grd.sum.objegfp to two decimal places
        {
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$graph.label <- round(plotdata.without.control$grd.sum.objegfp, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.plot.parameter, 2)
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = time, y = grd.sum.objegfp,
                                                                 shape = Codon.1, color = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          guides(colour = guide_legend(title = "UCAP (UAA)")) +
          
          guides(shape = guide_legend(title = "Codon")) +
          
          #geom_point(size = 1.5, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.15)) +
          
          stat_summary(fun = mean, geom = "point", size = 3, na.rm = TRUE, alpha = 0.5) +
          
          stat_summary(aes(y = nouaa.plot.parameter), fun = mean, geom = "point", size = 2, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               #subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        plotstore
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 7, height = 5, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      if(0 == 1){
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-200705 - Kinetics of mRSP Production for Most Prominent RS (change as needed by other systems)
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      exp.result.path <- paste(final.result.path, "200705_093441_Kinetics/", sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      target.data.path <- paste(sscp.pl11.path, "200705_093441_Image acquisition and analysis/", data.folder, sep = "")
      all.cpsummary.file <- paste(target.data.path, "All Plates CP Wells Summary (Analysis Started - 2022-04-19 19-55-19).csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.cpsummary.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
      all.experiment.data$read.time <- as.character(all.experiment.data$read.time)
      
      all.experiment.data$time <- NA
      all.experiment.data$time[all.experiment.data$read.time == "Read 1\t19 Hours"] <- 0
      all.experiment.data$time[all.experiment.data$read.time == "Read 2\t44 Hours"] <- 24
      all.experiment.data$time[all.experiment.data$read.time == "Read 3\t66 Hours"] <- 48
      all.experiment.data$time[all.experiment.data$read.time == "Read 4\tNA Hours"] <- 72
      
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 1\t19 Hours"] <- "Read 1\t0 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 2\t44 Hours"] <- "Read 2\t24 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 3\t66 Hours"] <- "Read 3\t48 Hours"
      all.experiment.data$read.time[all.experiment.data$read.time == "Read 4\tNA Hours"] <- "Read 4\t72 Hours"
      
      all.experiment.data$time <- as.factor(all.experiment.data$time)
      
    }
    
    # defines range
    upperend <- 100
    cutoff.value <- 25
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Kinetics"
      pdf.data.subset <- "mRSP Production (Only Prominent)"
      plot.title <- "mRaspberry Production Over Time"
      plot.subtitle <- ""
      y.axis.title <- "mRaspberry Produced (Fluorescence Units)\n"
      x.axis.title <- "\nRead Time (Hours)"
      fill.title.legend <- "Sample\n"
      
      # Plate 5 not processed properly, plate 10-13 will be handled later
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$platename == "Plate 1" |
                                          all.experiment.data$platename == "Plate 4" |
                                          all.experiment.data$platename == "Plate 8" |
                                          all.experiment.data$platename == "Plate 20" ) # Plate 20 is here as a nonsense value
      useful.shortlisted.data <- subset(useful.shortlisted.data, useful.shortlisted.data$UCAP.1 != "NoUCAP")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.01 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (", plotdata.without.control$UAA.1, ")", sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plateuid, plotdata.background$well.column, plotdata.background$read.time,
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plateuid, plotdata.without.control$well.column, plotdata.without.control$read.time,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.plot.parameter <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          #################################### Correct This ##############################
          plotdata.without.control$nouaa.plot.parameter[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$grd.sum.objmrsp[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # Convert chr to factor and round grd.sum.objmrsp to two decimal places
        {
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$graph.label <- round(plotdata.without.control$grd.sum.objmrsp, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.plot.parameter, 2)
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, aes(x = time, y = grd.sum.objmrsp,
                                                                 shape = Codon.1, color = Y.Axis.Text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          guides(colour = guide_legend(title = "UCAP (UAA)")) +
          
          guides(shape = guide_legend(title = "Codon")) +
          
          #geom_point(size = 1.5, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.15)) +
          
          stat_summary(fun = mean, geom = "point", size = 3, na.rm = TRUE, alpha = 0.5) +
          
          stat_summary(aes(y = nouaa.plot.parameter), fun = mean, geom = "point", size = 2, na.rm = TRUE, col = rgb(0.25,0.25,0.25,0.25)) +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               #subtitle = plot.subtitle,
               legend = fill.title.legend)
        
        plotstore
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 7, height = 5, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      if(0 == 1){
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
}

############################################################
############################################################
############################################################

## Endpoint Fluorescence Analysis

############################################################
############################################################
############################################################

## EXP-2021-05-30, 2021-06-05 and 2022-03-23 Heatmaps
{
  
  ## EXP-210530_210605
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      directory <- "210530_210605/"
      
      exp.result.path <- paste(final.result.path, directory, sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      all.endflu.file <- paste(endflu.results.path, directory,
                               "Endpoint Fluorescence - Multiple-Experiment-Data Aggregating File.csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.endflu.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    # defines range
    upperend <- 100
    cutoff.value <- 25
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "One Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - One Stop Codon in eGFP"
      plot.subtitle <- ""
      y.axis.title <- "G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nPosition on eGFP and Original Amino Acid"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$plate.info != "Plate20.csv")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.02 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$xprsn.normal[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$xprsn.normal[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ",
                                                              plotdata.without.control$UAA.1, sep = "")
        
        plotdata.without.control$Y.Axis.Text.Sorting[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$UCAP.1[plotdata.without.control$UAA.1 == "NoUAA"], sep = "")
        
        plotdata.without.control$Y.Axis.NoUAA.Sorting <- paste(plotdata.without.control$UCAP.1, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1, " (tRNA-", plotdata.without.control$Anticodon.1, ") + ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1,")", sep = "")
        
        plotdata.without.control$Y.Axis.Text[plotdata.without.control$UAA.1 == "NoUAA"] <- paste(plotdata.without.control$RS.1[plotdata.without.control$UAA.1 == "NoUAA"], " (tRNA-",
                                                                                                 plotdata.without.control$Anticodon.1[plotdata.without.control$UAA.1 == "NoUAA"], ")", sep = "")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, sep = "")
        
        # X.Axis.Text is final representation on Y-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)), sep = "")
        
        plotdata.background <- subset(plotdata.without.control, plotdata.without.control$UAA.1 == "NoUAA")
        plotdata.background$merger.code <- paste(plotdata.background$plate.info, plotdata.background$well.column, 
                                                 as.numeric(plotdata.background$well.row) - 1, sep = " + ")
        
        plotdata.without.control <- subset(plotdata.without.control, plotdata.without.control$UAA.1 != "NoUAA")
        plotdata.without.control$merger.code <- paste(plotdata.without.control$plate.info, plotdata.without.control$well.column,
                                                      as.numeric(plotdata.without.control$well.row), sep = " + ")
        
        plotdata.without.control$nouaa.well.row <- NA
        plotdata.without.control$nouaa.well.column <- NA
        plotdata.without.control$nouaa.plot.parameter <- NA
        
        all.mergercode <- plotdata.without.control$merger.code
        
        for(i in 1:length(all.mergercode)) {
          
          plotdata.without.control$nouaa.well.row[plotdata.without.control$merger.code == all.mergercode[i]] <-
            as.character(plotdata.background$well.row[plotdata.background$merger.code == all.mergercode[i]])
          
          plotdata.without.control$nouaa.well.column[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$well.column[plotdata.background$merger.code == all.mergercode[i]]
          
          plotdata.without.control$nouaa.plot.parameter[plotdata.without.control$merger.code == all.mergercode[i]] <-
            plotdata.background$xprsn.normal[plotdata.background$merger.code == all.mergercode[i]]
          
        }
        
        plotdata.without.control$column.check <- as.integer(plotdata.without.control$well.column) - as.integer(plotdata.without.control$nouaa.well.column)
        if(FALSE %in% (plotdata.without.control$column.check == 0)) {
          cat("Critical error!!!! Columns of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        if(FALSE %in% (plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "A"] == "B" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "C"] == "D" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "E"] == "F" &
                       plotdata.without.control$nouaa.well.row[plotdata.without.control$well.row == "G"] == "H")) {
          cat("Critical error!!!! Rows of plotdata.background are not correctly copied to plotdata.without.control.\n\nScript will exit.\n\n")
          exit()
        }
        
        rm(plotdata.background)
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round xprsn.normal to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$xprsn.normal, 2)
          plotdata.without.control$graph.background <- round(plotdata.without.control$nouaa.plot.parameter, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(cbind(graph.label, graph.background) ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting +Y.Axis.NoUAA.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$background.mean.values <- round(final.plot.label$graph.background[,1], 2)
        final.plot.label$background.error.values <- round(final.plot.label$graph.background[,2], 2)
        
        final.plot.label$bgrd.corrected.mean.values <- final.plot.label$mean.values - final.plot.label$background.mean.values
        final.plot.label$bgrd.corrected.error.values <- final.plot.label$error.values + final.plot.label$background.error.values
        
        final.plot.label$bgrd.corrected.error.bar.max <- final.plot.label$bgrd.corrected.mean.values + final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min <- final.plot.label$bgrd.corrected.mean.values - final.plot.label$bgrd.corrected.error.values
        final.plot.label$bgrd.corrected.error.bar.min[final.plot.label$bgrd.corrected.error.bar.min < 0] <- 0
        
        final.plot.label$bgrd.corrected.mean.values[final.plot.label$bgrd.corrected.mean.values < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$bgrd.corrected.mean.values, 2), "\n± ",
                                             round(final.plot.label$bgrd.corrected.error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = default.mean.values,
                                fill = default.mean.values, label = graph.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = background.mean.values,
                                fill = background.mean.values, label = background.mean.values)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background Corrected"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = bgrd.corrected.mean.values,
                                fill = bgrd.corrected.mean.values, label = graph.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
  ############################################################
  
  ## EXP-220323_004207
  {
    
    # Create output directory and read cpsummary file.
    {
      
      # Output directory
      directory <- "220323_004207/"
      
      exp.result.path <- paste(final.result.path, directory, sep = "")
      dir.create(path = exp.result.path)
      
      # Path for the cpsummary file
      all.endflu.file <- paste(endflu.results.path, directory,
                               "Endpoint Fluorescence - Multiple-Experiment-Data Aggregating File.csv", sep = "")
      
      all.experiment.data <- read.csv(file = all.endflu.file, header = TRUE, sep = ",", dec = ".")
      debug.all.experiment.data <- all.experiment.data
      
    }
    
    # defines range
    upperend <- 100
    cutoff.value <- 25
    
    {
      
      #define PDF file name
      pdf.graph.type <- "Heatmap"
      pdf.data.subset <- "Two Stop Codon - Complete"
      plot.title <- "Normalized Expression Ratio - Two Stop Codons in eGFP"
      plot.subtitle <- ""
      y.axis.title <- "G.C.E. System and UAA Present in Well\n"
      x.axis.title <- "\nPosition on eGFP and Original Amino Acid"
      fill.title.legend <- "Normalized\nExpression\nRatio\n"
      
      # defines range
      upperend <- 100
      cutoff.value <- 25
      
      useful.shortlisted.data <- subset(all.experiment.data, all.experiment.data$plate.info == "Plate 5.csv" |
                                          all.experiment.data$plate.info == "Plate 6.csv")
      
      {
        data.formatting.buffer <- useful.shortlisted.data
        source(file = paste(sourcecode.path, "10.02 Final Results Script (Formatting data.formatting.buffer).R", sep = ""))
        useful.shortlisted.data <- data.formatting.buffer
        rm(data.formatting.buffer)
      }
      
      # Define Blueline and Redline
      {
        blueline <- round(mean(useful.shortlisted.data$xprsn.normal[useful.shortlisted.data$system.Detail == "All Control Both"], na.rm = TRUE), 2)
        redline <- round(mean(useful.shortlisted.data$xprsn.normal[useful.shortlisted.data$system.Detail == "All Control mRSP"], na.rm = TRUE), 2)
        
        # In case redline was not determined for some case
        if(is.nan(redline)) { redline <- 0 }
        if(is.nan(blueline)) { blueline <- 100 }
      }
      
      {
        
        # plotdata.without.control is shortlisted data without "Controls"
        plotdata.without.control <- subset(useful.shortlisted.data, useful.shortlisted.data$sample.set != "All Control")
        
        # X.Axis.Text.Sorting is used for sorting values on X-Axis
        plotdata.without.control$X.Axis.Text.Sorting <- paste(plotdata.without.control$Position.1, " (", plotdata.without.control$Codon.1, ") + ",
                                                              plotdata.without.control$Position.2, " (", plotdata.without.control$Codon.2, ")", sep = "")
        
        # X.Axis.Text is final representation on X-Axis
        plotdata.without.control$X.Axis.Text <- paste(plotdata.without.control$Original.AA.1,
                                                      as.integer(substr(plotdata.without.control$Position.1, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.1, " and\n",
                                                      plotdata.without.control$Original.AA.2,
                                                      as.integer(substr(plotdata.without.control$Position.2, start = 2, stop = 4)),
                                                      plotdata.without.control$Codon.2, sep = "")
        
        # Y.Axis.Text.Sorting is used for sorting values on Y-Axis
        plotdata.without.control$Y.Axis.Text.Sorting <- paste(plotdata.without.control$UCAP.1, " + ", plotdata.without.control$UCAP.2, " + ",
                                                              plotdata.without.control$UAA.1, " + ", plotdata.without.control$UAA.2, sep = "")
        
        # Y.Axis.Text is final representation on Y-Axis
        plotdata.without.control$Y.Axis.Text <- paste(plotdata.without.control$RS.1," (tRNA-", plotdata.without.control$Anticodon.1, ") and\n",
                                                      plotdata.without.control$RS.2," (tRNA-", plotdata.without.control$Anticodon.2, ") with\n ",
                                                      plotdata.without.control$UAA.1, " (", plotdata.without.control$Conc.1, ") and ",
                                                      plotdata.without.control$UAA.2, " (", plotdata.without.control$Conc.2, ")", sep = "")
        
        # plot.reorder is needed to make convert between Axis.Text and Axis.Text.Sorting
        {
          plot.axis.rename.x.axis <- aggregate(X.Axis.Text ~ X.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.rename.y.axis <- aggregate(Y.Axis.Text ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          plot.axis.color.y.axis <- aggregate(RS.1 ~ Y.Axis.Text.Sorting, plotdata.without.control, unique)
          colnames(plot.axis.color.y.axis) <- c("Y.Axis.Text.Sorting", "colour.class")
        }
        
        control.text.height <- levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))[
          as.integer(length(levels(as.factor(as.character(plotdata.without.control$Y.Axis.Text.Sorting)))))/2]
        
        # Convert chr to factor and round xprsn.normal to two decimal places
        {
          plotdata.without.control$X.Axis.Text <- as.factor(plotdata.without.control$X.Axis.Text)
          plotdata.without.control$X.Axis.Text.Sorting <- as.factor(plotdata.without.control$X.Axis.Text.Sorting)
          plotdata.without.control$Y.Axis.Text <- as.factor(plotdata.without.control$Y.Axis.Text)
          plotdata.without.control$Y.Axis.Text.Sorting <- as.factor(plotdata.without.control$Y.Axis.Text.Sorting)
          plotdata.without.control$graph.label <- round(plotdata.without.control$xprsn.normal, 2)
        }
        
        # final.plot.label is used to create labels on the heatmap
        final.plot.label <- aggregate(graph.label ~ X.Axis.Text.Sorting + Y.Axis.Text.Sorting,
                                      plotdata.without.control,
                                      FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE), n = length(x), max = max(x, na.rm = TRUE)))
        
        # graph.text column contains "value ± standard deviation" (used for display)
        final.plot.label$graph.text <- paste(round(final.plot.label$graph.label[,1], 2), "\n± ",
                                             round(final.plot.label$graph.label[,2], 2), sep = "")
        
        # add values for graphs
        final.plot.label$graph.labeldist <- final.plot.label$graph.label[,4]
        final.plot.label$mean.values <- round(final.plot.label$graph.label[,1], 2)
        final.plot.label$error.values <- round(final.plot.label$graph.label[,2], 2)
        final.plot.label$error.bar.max <- final.plot.label$mean.values + final.plot.label$error.values
        final.plot.label$error.bar.min <- final.plot.label$mean.values - final.plot.label$error.values
        final.plot.label$error.bar.min[final.plot.label$error.bar.min < 0] <- 0
        
        final.plot.label$graph.text <- paste(round(final.plot.label$mean.values, 2), "\n± ",
                                             round(final.plot.label$error.values, 2),
                                             #" \t", "(N = ", final.plot.label$graph.label[,3], ")",
                                             sep = "")
        
        final.plot.label$default.mean.values <- round(final.plot.label$graph.label[,1], 2)
        
        all.x.sorting.levels <- levels(final.plot.label$X.Axis.Text.Sorting)
        all.y.sorting.levels <- levels(final.plot.label$Y.Axis.Text.Sorting)
        
        len.x <- length(all.x.sorting.levels)
        len.y <- length(all.y.sorting.levels)
        
        if(FALSE %in% (all.x.sorting.levels == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in final.plot.label")
          exit()
        }
        if(FALSE %in% (all.y.sorting.levels == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in final.plot.label")
          exit()
        }
        
        final.plot.label$colour.class <- NA
        
        for(i in 1:len.y) {
          
          final.plot.label$colour.class[final.plot.label$Y.Axis.Text.Sorting == all.y.sorting.levels[i]] <-
            as.character(plot.axis.color.y.axis$colour.class[plot.axis.rename.y.axis$Y.Axis.Text.Sorting == all.y.sorting.levels[i]])
          
        }
        
        final.plot.label$colour.class <- as.factor(final.plot.label$colour.class)
        
        if(FALSE %in% (levels(plotdata.without.control$X.Axis.Text.Sorting) == plot.axis.rename.x.axis$X.Axis.Text.Sorting)) { 
          print("Critical error!!!! plot.axis.rename.x.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        if(FALSE %in% (levels(plotdata.without.control$Y.Axis.Text.Sorting) == plot.axis.rename.y.axis$Y.Axis.Text.Sorting)) {
          print("Critical error!!!! plot.axis.rename.y.axis does not match levels in plotdata.without.control. Graph will be affected.")
          exit()
        }
        
      }
      
      {
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = default.mean.values,
                                fill = default.mean.values, label = graph.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 10, height = 9, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = background.mean.values,
                                fill = background.mean.values, label = background.mean.values)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      {
        
        pdf.data.subset <- "One Stop Codon - Background Corrected"
        
        # plotstore contains the plot
        plotstore <- ggplot(data = plotdata.without.control, na.rm = TRUE,
                            aes(x = X.Axis.Text.Sorting, y = Y.Axis.Text.Sorting, z = bgrd.corrected.mean.values,
                                fill = bgrd.corrected.mean.values, label = graph.text)) + theme_bw() +
          
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
          
          theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
                plot.subtitle = element_text(color = "Blue", hjust = 0.5),
                plot.title = element_text(color = "Red", size = 15, face = "bold", hjust = 0.5)) +
          
          geom_tile(data = final.plot.label, na.rm = TRUE) +
          
          scale_fill_gradient2(low = "Red", mid = "Beige", high = "Blue", limits = c(0,upperend), oob=squish, na.value = "Red") +
          
          labs(title = plot.title,
               x = x.axis.title,
               y = y.axis.title,
               subtitle = plot.subtitle,
               fill = fill.title.legend)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Default Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + scale_y_discrete(labels = plot.axis.rename.y.axis$Y.Axis.Text) + scale_x_discrete(labels = plot.axis.rename.x.axis$X.Axis.Text)
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (Modified Axis) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 8, height = 9, units = "in", limitsize = FALSE)
        
        plotstore <- plotstore + geom_text(data = final.plot.label, size = 3, col = rgb(0.25,0.25,0.25,0.50))
        
        ggsave(plot = plotstore,
               filename = paste(exp.result.path, pdf.graph.type, " (With Labels) - ", pdf.data.subset, " (Scale 0-", upperend, ").pdf", sep = ""),  
               device = "pdf", width = 12, height = 15, units = "in", limitsize = FALSE)
        
      }
      
      # Remove old plots to avoid confusion
      {
        
        rm(plotdata.without.control)
        rm(final.plot.label)
        rm(plot.axis.rename.x.axis)
        rm(plot.axis.rename.y.axis)
        rm(plotstore)
        rm(useful.shortlisted.data)
        rm(upperend)
        rm(plotdata.after.cutoff)
        
        rm(pdf.graph.type)
        rm(pdf.data.subset)
        rm(plot.title)
        rm(plot.subtitle)
        rm(y.axis.title)
        rm(x.axis.title)
        rm(fill.title)
        
      }
      
    }
    
  }
  
}















