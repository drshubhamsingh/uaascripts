cpqc <- FALSE

if(numberofwellsinplate == 96) {
  
  topwell.row = c("A", "B", "C", "D")
  bottomwell.row = c("E", "F", "G", "H")
  
  scatterplotrows <- 8
  scatterplotcolumns <- 12
  
  pdfwidth <- 12
  pdfheight <- 15
  maxpdfheight <- 50
  cat(paste("PDF Dimensions Defined. PDF Width:", pdfwidth, "inch. PDF Height:", pdfheight, "inch."))
  
  smallpdfwidth <- 10
  smallpdfheight <- 8
  
  mediumpdfwidth <- 10
  mediumpdfheight <- 40
  
  posterpdfwidth <- 60
  posterpdfheight <- 40
  
  kineticspdfwidth <- 10
  kineticspdfheight <- 7
  
  cat("Parameters loaded for 96 well plate")
  
}

if(numberofwellsinplate == 384) {
  
  topwell.row = c("A", "B", "C", "D", "I", "J", "K", "L")
  bottomwell.row = c("E", "F", "G", "H", "M", "N", "O", "P")
  
  scatterplotrows <- 16
  scatterplotcolumns <- 24
  
  pdfwidth <- 12
  pdfheight <- 15
  maxpdfheight <- 80
  cat(paste("Standard PDF Dimensions Defined. PDF Width:", pdfwidth, "inch. PDF Height:", pdfheight, "inch."))
  
  smallpdfwidth <- 10
  smallpdfheight <- 15
  
  mediumpdfwidth <- 10
  mediumpdfheight <- 60
  
  posterpdfwidth <- 120
  posterpdfheight <- 80
  
  kineticspdfwidth <- 10
  kineticspdfheight <- 7
  
  cat("Parameters loaded for 384 well plate")
  
}

colorhue <- function(g, r, t) {
  colhue <- g/r
  colhue <- max(colhue-0.25, 0, na.rm = TRUE)
  colhue <- min(colhue, 1)
  rgbval  <- rgb((1-colhue)^(1/5), colhue^(1/5), 0, t)
  return(rgbval)
}
print("ColorHue Defined", quote = FALSE)

legend.title <- "Sample Type"

errorbar.width <- 0.3
ggplot.positiondodge.value <- 0.9
errobar.color <- rgb(0,0,0,0.5)

subtitle.color <- rgb(0,0,1,0.5)
title.color <- rgb(1,0,0,0.75)
title.size <- 12

control.max.text.color <- rgb(0,0,0.5,1)
control.min.text.color <- rgb(1,0,0,1)
control.max.line.color <- rgb(0,0,0.5,0.75)
control.min.line.color <- rgb(1,0,0,0.75)
control.min.line.width <- 0.2
control.min.line.type <- "dashed"

data.points.color <- rgb(0,0,0,0.5)
data.points.size <- 3
data.points.pch <- "x"

sample.type.stat.summary.geom <- "point"
sample.type.stat.summary.shape <- 16
sample.type.stat.summary.size <- 2
sample.type.boxplot.main.width <- 0.70
sample.type.boxplot.supp.width <- 0.35

sample.type.color.manual.values <- c(rgb(0.06,0.13,0.5,0.75), rgb(0.96,0.47,0.23,0.75))

data.label.color <- rgb(0.25,0.45,0.60,0.75)

sample.type.xaxis.label <- "Percent Incorporation"
sample.type.yaxis.label <- ""
sample.type.legend.label <- "Sample"
sample.type.subtitle.text <- "Solid circles respresent the averages. Numbers represent percent incorporation for complete system.
x represent individual data points for complete system."

kinetics.color.manual.values <- c(rgb(0.06,0.13,0.5,0.5), rgb(0.8,0.6,0.7,0.75), rgb(0,0.45,0.7,0.5), rgb(0,0.6,0.5,0.5), rgb(0.8,0.4,0,0.5), rgb(1.0,0.6,0,0.5))
kinetic.color.single.value <- rgb(0.06,0.13,0.5,0.5)
kinetic.color.single.value.line <- rgb(0.06,0.13,0.5,0.25)

kinetics.shape.manual.values <- c(0:25, 0:25)

# comment the following line if "sample.type.color.manual.labels" value is not provided
#kinetics.shape.manual.labels <- sample.type.color.manual.labels
kinetic.point.size <- 4

object.details.violin.fill <- rgb(0,1,0,0.25)
object.details.violin.width <- 0.65

object.details.xaxis.label <- "Value"
object.details.yaxis.label <- ""

object.details.points.size <- 1.5
object.details.points.color <- rgb(1,0,0,0.75)
object.details.points.shape <- 16

object.details.welldetail.color <- rgb(1,0,0,0.2)
object.details.topwells.shape <- 4
object.details.bottomwells.shape <- 3

kinetics.object.details.welldetail.color <- rgb(0,0,0,0.05)
kinetics.object.details.topwells.shape <- 4
kinetics.object.details.bottomwells.shape <- 3
kinetics.range.line.color <- rgb(0,0,0,0.05)

object.details.text.color <- "black"

object.details.data.size <- 1.5
object.details.data.color <- rgb(0,0,1,0.5)
object.details.data.shape <- 16

object.details.histogram.border <- rgb(0.25,0.25,0.25,0.25)
object.details.histogram.breaks <- 20
object.details.densityline.color <- rgb(0, 0, 0.75, 0.75)
object.details.densityline.width <- 2
object.details.densityline.type <- "longdash"

object.details.data.color <- rgb(0,0,1,0.5)
object.details.data.shape <- 16

print("Color values loaded ..... Graphics Settings Script Sourced", quote = FALSE)