## Install needed packages
{
  
  ## When more packages are needed, add it to this list
  packages.needed <- c("ggplot2", "stringr", "pheatmap", "plyr", "scales",
                       "dplyr", "tidyverse", "reshape", "scales")
  install.packages(setdiff(packages.needed, rownames(installed.packages())))
  
}

## Load the needed packages
for (boni in 1:length(packages.needed)) {
  
  eval(parse(text = paste("library(", noquote(unname(packages.needed[boni])), ")", sep = "")))
  print(paste("library ", noquote(unname(packages.needed[boni])), " is loaded", sep = ""), quote = FALSE)
  
}

## Remove unnecessary variables
rm(boni)
rm(packages.needed)

## Define exit function to Quit the Processing when a critical error is encountered
exit <- function() {
  .Internal(.invokeRestart(list(NULL, NULL), NULL))
}