## For Image Analysis

data.formatting.buffer$well.id <- factor(data.formatting.buffer$well.id)
data.formatting.buffer$well.row <- factor(data.formatting.buffer$well.row)
data.formatting.buffer$well.column <- factor(data.formatting.buffer$well.column)

data.formatting.buffer$kinetic.position <- factor(data.formatting.buffer$kinetic.position)
data.formatting.buffer$bottom.or.top <- factor(data.formatting.buffer$bottom.or.top)

data.formatting.buffer$Anticodon.1 <- factor(data.formatting.buffer$Anticodon.1)
data.formatting.buffer$Anticodon.2 <- factor(data.formatting.buffer$Anticodon.2)

data.formatting.buffer$Codon.1 <- factor(data.formatting.buffer$Codon.1)
data.formatting.buffer$Codon.2 <- factor(data.formatting.buffer$Codon.2)

data.formatting.buffer$Conc.1 <- factor(data.formatting.buffer$Conc.1)
data.formatting.buffer$Conc.2 <- factor(data.formatting.buffer$Conc.2)

data.formatting.buffer$Keyword <- factor(data.formatting.buffer$Keyword)

data.formatting.buffer$Original.AA.1 <- factor(data.formatting.buffer$Original.AA.1)
data.formatting.buffer$Original.AA.2 <- factor(data.formatting.buffer$Original.AA.2)

data.formatting.buffer$POI.1 <- factor(data.formatting.buffer$POI.1)
data.formatting.buffer$POI.2 <- factor(data.formatting.buffer$POI.2)

data.formatting.buffer$POI.Name.1 <- factor(data.formatting.buffer$POI.Name.1)
data.formatting.buffer$POI.Name.2 <- factor(data.formatting.buffer$POI.Name.2)

data.formatting.buffer$Position.1 <- factor(data.formatting.buffer$Position.1)
data.formatting.buffer$Position.2 <- factor(data.formatting.buffer$Position.2)

data.formatting.buffer$RS.1 <- factor(data.formatting.buffer$RS.1)
data.formatting.buffer$RS.2 <- factor(data.formatting.buffer$RS.2)

data.formatting.buffer$tRNA.1 <- factor(data.formatting.buffer$tRNA.1)
data.formatting.buffer$tRNA.2 <- factor(data.formatting.buffer$tRNA.2)

data.formatting.buffer$UAA.1 <- factor(data.formatting.buffer$UAA.1)
data.formatting.buffer$UAA.2 <- factor(data.formatting.buffer$UAA.2)

data.formatting.buffer$UCAP.1 <- factor(data.formatting.buffer$UCAP.1)
data.formatting.buffer$UCAP.2 <- factor(data.formatting.buffer$UCAP.2)

data.formatting.buffer$sample.set <- factor(data.formatting.buffer$sample.set)
data.formatting.buffer$sample.type <- factor(data.formatting.buffer$sample.type)

data.formatting.buffer$well.no <- factor(data.formatting.buffer$well.no)

data.formatting.buffer$system.UCAP.all <- factor(data.formatting.buffer$system.UCAP.all)
data.formatting.buffer$system.DNA <- factor(data.formatting.buffer$system.DNA)
data.formatting.buffer$system.UAA <- factor(data.formatting.buffer$system.UAA)
data.formatting.buffer$system.GCE <- factor(data.formatting.buffer$system.GCE)
data.formatting.buffer$system.Detail <- factor(data.formatting.buffer$system.Detail)

data.formatting.buffer$Background.Info <- factor(data.formatting.buffer$Background.Info)

data.formatting.buffer$read.time <- factor(data.formatting.buffer$read.time)

data.formatting.buffer$platedate <- factor(data.formatting.buffer$platedate)
data.formatting.buffer$platetime <- factor(data.formatting.buffer$platetime)

data.formatting.buffer$platename <- factor(data.formatting.buffer$platename)
data.formatting.buffer$plateuid <- factor(data.formatting.buffer$plateuid)