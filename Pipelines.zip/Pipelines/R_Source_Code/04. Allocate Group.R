allplates.platenames <- NULL
allplates.platenames <- levels(plate.names$plate.no)

original.ncol.allocate.dataframe <- ncol(allocate.dataframe)

if(length(allplates.platenames) > 9) {
  if(allplates.platenames[2] != "Plate.02") {
    cat("!!!WARNING!!! The total number of plates is more than 9.\nThis requires very careful naming of the plate (as in Plate01 rather than Plate1).\nThe program will exit")
    exit()
  }
}

if(length(allocate.dataframe$well.id) == 0) {
  cat("!!!WARNING!!! The parameter allocate.dataframe$well.id has not been defined.\nProgram will exit.")
  exit()
}

plate.names.allocate <- NULL
plate.names.allocate <- subset(plate.names, plate.no == allplates.platenames[file.no])
plate.names.allocate <- data.frame(lapply(plate.names.allocate, as.character), stringsAsFactors = FALSE)

sample.attributes.new <- c(sample.attributes, "sample.set", "sample.type")
atr <- length(sample.attributes.new)
for(i in 1:atr) {
  
  column.names.allocate.dataframe <- NULL
  column.names.allocate.dataframe <- colnames(allocate.dataframe)
  
  allocate.dataframe[ncol(allocate.dataframe)+1] <- as.character(NA)
  colnames(allocate.dataframe) <- c(column.names.allocate.dataframe, sample.attributes.new[i])
  
  rm(column.names.allocate.dataframe)
  
}

new.ncol.allocate.dataframe <- ncol(allocate.dataframe)

# CAUTION - This is the most time consuming and memory-intensive step
for (i in 1:length(well.all)) {
  
  rowstemp <- NULL
  rowstemp <- length(well.all[[i]][1, ])
  
  colstemp <- NULL
  colstemp <- length(well.all[[i]][, 1])
  
  sample <- NULL
  
  if ( i != 1  &  i < (length(plate.names.allocate$well.id)+1 ) ) {
    
    control.parameters <- NULL
    control.parameters <- plate.names.allocate[plate.names.allocate$well.cp == as.character(well.all[[i]][1, ]),]
    
  }
  
  for (j in 1:colstemp) {
    # rows of the data.frame here
    
    for (k in 1:rowstemp) {
      # columns of the data.frame here here
      
      cat(paste("Allocate.R - Processing well", as.character(well.all[[i]][j, k]), "\n"))
      
      if(i != 1) {
        
        for(m in 1:(atr)) {
          
          if(as.character(well.all[[i]][1, ]) %in% plate.names.allocate$well.cp) {
            
            allocate.dataframe[allocate.dataframe$well.id == as.character(well.all[[i]][j, k]), m+original.ncol.allocate.dataframe] <-
              plate.names.allocate[plate.names.allocate$well.cp == as.character(well.all[[i]][1, ]), m+4]
            
          }
          
        }
        
      }
      
      if (i == 1) {
        
        if (k == 1) { sample <- Control1 }
        if (k == 2) { sample <- Control2 }
        if (k == 3) { sample <- Control3 }
        if (k == 4) { sample <- Control4 }
        
        allocate.dataframe[allocate.dataframe$well.id == as.character(well.all[[i]][j, k]), (new.ncol.allocate.dataframe-1)] <- "All Control"
        
        allocate.dataframe[allocate.dataframe$well.id == as.character(well.all[[i]][j, k]), (new.ncol.allocate.dataframe)] <- sample
        
      }
      
    }
    
  }
  
}

for(m in 1:atr) { allocate.dataframe[m+original.ncol.allocate.dataframe] <- lapply(allocate.dataframe[m+original.ncol.allocate.dataframe], factor) }

print("Well classification completed.", quote = FALSE)

print("Script Allocate Group.R was sourced successfully", quote = FALSE)