numberofwellsinplate <- 384
adjacent.sample.and.nouaa <- FALSE

source(file = paste(sep = "", sourcecode.path, "00. Install and Load Packages.R"))

runtime <- Sys.time()
runtime <- gsub(pattern = "[a-zA-Z]", replacement = "", x = runtime)
runtime <- gsub(pattern = ":", replacement = "-", x = runtime)
print(paste("Runtime is", runtime), quote = FALSE)

generatedfilesfolder <- paste("Analysis Generated Files", .Platform$file.sep, sep = "")
dir.create(path = generatedfilesfolder)

pdfpath <- paste("Output PDF", .Platform$file.sep, sep = "")
pdfpath.qc <- paste("Output PDF QC", .Platform$file.sep, sep = "")
excelpath <- paste("Output Excel", .Platform$file.sep, sep = "")

## Four Controls of the Plate
Control1 <- "NoFP"    # Default Control1 <- "NoFP". DO NOT CHANGE.
Control2 <- "mRSP"    # Default Control2 <- "mRSP". DO NOT CHANGE.
Control3 <- "eGFP"    # Default Control3 <- "eGFP". DO NOT CHANGE.
Control4 <- "Both"    # Default Control4 <- "Both". DO NOT CHANGE.

if(adjacent.sample.and.nouaa == TRUE) {
  
  Sample1 <- "Sample" # Default Sample1 <- "Sample" ## NOTE: Default is defined because any name can be used.
  Sample2 <- "noUAA"  # Default Sample2 <- "noUAA"  ## NOTE: Default is defined because any name can be used.
  
}

if(numberofwellsinplate == 96) {
  wellrows <- c("A", "B", "C", "D", "E", "F", "G", "H")
  wellcolumns <- c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12")
}

if(numberofwellsinplate == 384) {
  wellrows <- c("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P")
  wellcolumns <- c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24")
}

well.name <- NULL
wellcounter <- 1

for (i in 1:length(wellrows)) {
  for (j in 1:length(wellcolumns)) {
    well.name[wellcounter] <-
      paste(wellrows[i], wellcolumns[j], sep = "")
    wellcounter <- wellcounter + 1
  }
}
rm(wellcounter)

if(numberofwellsinplate == 96) {
  
  halfwellcount <- length(well.name)/2
  names(well.name) <- c(rep("top.well", halfwellcount), rep("bottom.well", halfwellcount))
  
  duprows <- list(c("A", "E"), c("B", "F"), c("C", "G"), c("D", "H"))
  names(duprows) <- c("A", "B", "C", "D")
  
  dupcolumns <- list(c("1", "2", "12"), c("3", "6", "9"), c("4", "7", "10"), c("5", "8", "11"))
  names(dupcolumns) <- c("ColSet1", "ColSet2", "ColSet3", "ColSet4")
  
}

if(numberofwellsinplate == 384) {
  
  halfwellcount <- length(well.name)/4
  names(well.name) <- c(rep("top.well", halfwellcount), rep("bottom.well", halfwellcount), rep("top.well", halfwellcount), rep("bottom.well", halfwellcount))
  
  duprows <- list(c("A", "E"), c("B", "F"), c("C", "G"), c("D", "H"), c("I", "M"), c("J", "N"), c("K", "O"), c("L", "P"))
  names(duprows) <- c("A", "B", "C", "D", "I", "J", "K", "L")
  
  dupcolumns <- list(c("1", "2", "3"), c("4", "5", "6"), c("7", "8", "9"), c("10", "11", "12"), c("13", "14", "15"), c("16", "17", "18"), c("19", "20", "21"), c("22", "23", "24"))
  names(dupcolumns) <- c("ColSet1", "ColSet2", "ColSet3", "ColSet4", "ColSet5", "ColSet6", "ColSet7", "ColSet8")  
  
}

file.list.folder <- NULL
file.list.folder <- list.files()

if (length(file.list.folder[file.list.folder == "Special Arrangement.R"]) != 0) { source(file = "Special Arrangement.R") }
rm(file.list.folder)

dupwells <- function(x, y) {
  
  colvals <- dupcolumns[names(dupcolumns) == x]
  rowvals <- duprows[names(duprows) == y]
  
  output <- NULL
  k <- 1
  
  for (i in 1:length(colvals[[1]])) {
    for (j in 1:length(rowvals[[1]])) {
      output[k] <- paste(rowvals[[1]][j], colvals[[1]][i], sep = "")
      k <- k + 1
    }
  }
  
  return(output)
  
}

if(numberofwellsinplate == 96) {
  well.NoFP <- dupwells("ColSet1", "A")
  well.mRSP <- dupwells("ColSet1", "C")
  well.eGFP <- dupwells("ColSet1", "B")
  well.Both <- dupwells("ColSet1", "D")
}

if(numberofwellsinplate == 384) {
  well.NoFP <- dupwells("ColSet1", "A")
  well.mRSP <- dupwells("ColSet1", "B")
  well.eGFP <- dupwells("ColSet1", "C")
  well.Both <- dupwells("ColSet1", "D")
}

if(!exists("only.endflo.analysis")) { source(file = "Experiment Details.R") }
controls <- data.frame(well.NoFP, well.mRSP, well.eGFP, well.Both)
colnames(controls) <- c(Control1, Control2, Control3, Control4)

well.all <- NULL
well.all[[1]] <- data.frame(controls)

i <- 2
for(j in 1:length(duprows)) {
  
  colcounter <- 2
  
  if(j > 4) { colcounter <- 1 }
  
  for(k in colcounter:length(dupcolumns)) {
    
    well.all[[i]] <- data.frame(dupwells(names(dupcolumns[k]), names(duprows[j])))
    
    sys.counter <- as.character(i)
    if(i < 10) { sys.counter <- paste("0", sys.counter, sep = "") }
    
    colnames(well.all[[i]]) <- paste("System", sys.counter, sep = "")
    
    i <- i + 1
    
  }
  
}

std <- function(x, na.rm = FALSE) {
  if (na.rm) x <- na.omit(x)
  sqrt(var(x) / length(x))
}

print(paste("Plate Setup defined and loaded for a", numberofwellsinplate,"well-plate. Script will continue..."), quote = FALSE)

directorycsv <- FALSE