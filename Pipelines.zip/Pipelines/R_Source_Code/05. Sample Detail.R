# Basically, this script makes new fields to the data-frame "sample.detail.df", which can later be used to sort or group data-points.

sample.detail.df$well.row <- substr(sample.detail.df$well.id, 1, 1)

sample.detail.df$well.column  <- as.integer(sample.detail.df$well.column)
sample.detail.df$well.column[sample.detail.df$well.column < 10] <- paste("0", sample.detail.df$well.column[sample.detail.df$well.column < 10], sep = "")

sample.detail.df$well.no <- paste(sample.detail.df$well.row, sample.detail.df$well.column, sep = "")

sample.detail.df$well.column <- factor(sample.detail.df$well.column)
sample.detail.df$well.row <- factor(sample.detail.df$well.row)
sample.detail.df$well.no <- factor(sample.detail.df$well.no)

sample.detail.df$system.UCAP.all <- paste(sample.detail.df$UCAP.1, sample.detail.df$UCAP.2, sep = " + ")
sample.detail.df$system.UCAP.all[is.na(sample.detail.df$UCAP.2)] <- paste(sample.detail.df$UCAP.1[is.na(sample.detail.df$UCAP.2)], sep = " + ")
sample.detail.df$system.UCAP.all[is.na(sample.detail.df$UCAP.1)] <- NA

sample.detail.df$system.DNA <- paste(sample.detail.df$POI.Name.1, sample.detail.df$UCAP.1, sample.detail.df$UCAP.2, sep = " + ")
sample.detail.df$system.DNA[is.na(sample.detail.df$UCAP.2)] <- paste(sample.detail.df$POI.Name.1[is.na(sample.detail.df$UCAP.2)], sample.detail.df$UCAP.1[is.na(sample.detail.df$UCAP.2)], sep = " + ")
sample.detail.df$system.DNA[is.na(sample.detail.df$UCAP.1)] <- NA

sample.detail.df$system.UAA <- paste(sample.detail.df$UAA.1, sample.detail.df$UAA.2, sep = " + ")
sample.detail.df$system.UAA[is.na(sample.detail.df$UAA.2)] <- paste(sample.detail.df$UAA.1[is.na(sample.detail.df$UAA.2)], sep = " + ")
sample.detail.df$system.UAA[is.na(sample.detail.df$UAA.1)] <- NA

sample.detail.df$system.GCE <- paste(sample.detail.df$UCAP.1, sample.detail.df$UAA.1, sample.detail.df$UCAP.2, sample.detail.df$UAA.2, sep = " + ")
sample.detail.df$system.GCE[is.na(sample.detail.df$UCAP.2)] <- paste(sample.detail.df$UCAP.1[is.na(sample.detail.df$UCAP.2)], sample.detail.df$UAA.1[is.na(sample.detail.df$UCAP.2)], sep = " + ")
sample.detail.df$system.GCE[is.na(sample.detail.df$UCAP.1)] <- NA

sample.detail.df$system.Detail <- paste(sample.detail.df$system.DNA, sample.detail.df$system.UAA, sep = " + ")
sample.detail.df$system.Detail[is.na(sample.detail.df$system.DNA)] <- paste(sample.detail.df$sample.set[is.na(sample.detail.df$system.DNA)], sample.detail.df$sample.type[is.na(sample.detail.df$system.DNA)], sep = " ")

sample.detail.df$Background.Info <- paste(sample.detail.df$POI.Name.1, sample.detail.df$sample.set, sep = " - ")
sample.detail.df$Background.Info[is.na(sample.detail.df$POI.Name.1)] <- NA

sample.detail.df$system.DNA <- factor(sample.detail.df$system.DNA)
sample.detail.df$system.UAA <- factor(sample.detail.df$system.UAA)
sample.detail.df$system.GCE <- factor(sample.detail.df$system.GCE)
sample.detail.df$system.Detail <- factor(sample.detail.df$system.Detail)
sample.detail.df$system.UCAP.all <- factor(sample.detail.df$system.UCAP.all)
sample.detail.df$Background.Info <- factor(sample.detail.df$Background.Info)

print("Sample Details Added.", quote = FALSE)

print("Script Sample Details.R was sourced successfully", quote = FALSE)
