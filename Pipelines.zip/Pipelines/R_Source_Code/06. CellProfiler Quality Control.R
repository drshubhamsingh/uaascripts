# QC Plot 1 - Total eGFP Histogram
print("Plotting Histogram and Distribution for eGFP", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 1. eGFP Histogram.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 1 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.kinetic$well.id == well.name[i]
  
  if (length(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue]) < 100) {
    # Blank for histogram plot
    plot(-1, -1, xlab = "Total eGFP per Object", ylab = "Count", main = paste("< 100 values. Display cancelled for", well.name[i]),
         pch = 3, axes = FALSE, ylim = c(0, 10), xlim = c(min(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, 0, na.rm = TRUE), 
                                                          max(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, na.rm = TRUE)))
    axis(1)
    axis(2)
  }
  
  if (length(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue]) >= 100) {
    
    dens <- density(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue])
    peakx <- dens$x[dens$y == max(dens$y)]
    peaky <- max(dens$y)
    
    # Histogram plot
    hist(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue], main = paste("Total eGFP (without background correction) distribution for Well", well.name[i]),
         xlab = "Total eGFP per Object", col = "green", ylim = c(0, 2 * peaky), border = object.details.histogram.border, breaks = object.details.histogram.breaks,
         probability = TRUE, xlim = c(min(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, 0, na.rm = TRUE), 
                                      max(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, na.rm = TRUE)))
    
    lines(dens, col = object.details.densityline.color, lwd = object.details.densityline.width, lty = object.details.densityline.type)
    
    abline(v = peakx, lwd = 1.5, col = rgb(0, 0, 1, 0.5), lty = "longdash")
    text(peakx, 1.1 * max(dens$y), pos = 4, col = rgb(0, 0, 1, 1), srt = 90, cex = 1.2, labels = paste("Peak =", round(peakx, 2)), offset = -0.75)
    
    meantext <- NULL
    meantext <- mean(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue], na.rm = TRUE)
    abline(v = meantext, lwd = 1.5, col = rgb(1, 0, 0, 0.5), lty = "longdash")
    text(meantext, 1.1 * max(dens$y), pos = 4, lwd = 2, col = rgb(1, 0, 0, 1), offset = 0.75, srt = 90, cex = 1.2, labels = paste("Mean =", round(meantext, 2)))
    
    text(0.7 * max(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, na.rm = TRUE), 1.1 * max(dens$y), pos = 1, col = rgb(0, 0, 1, 1),
         cex = 1.5, srt = 0, labels = paste("n = ", length(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue]), sep = ""))
    
  }
  
}
dev.off()

# QC Plot 2 - Total mRSP Histogram
print("Plotting Histogram and Distribution for mRSP", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 2. mRSP Histogram.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 2 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.kinetic$well.id == well.name[i]
  
  if (length(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue]) < 100) {
    # Blank for histogram plot
    plot(-1, -1, xlab = "Total mRSP per Object", ylab = "Count", main = paste("< 100 values. Display cancelled for", well.name[i]),
         pch = 3, axes = FALSE, ylim = c(0, 10), xlim = c(min(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, 0, na.rm = TRUE), 
                                                          max(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, na.rm = TRUE)))
    axis(1)
    axis(2)
  }
  
  if (length(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue]) >= 100) {
    
    dens <- density(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue])
    peakx <- dens$x[dens$y == max(dens$y)]
    peaky <- max(dens$y)
    
    # Histogram plot
    hist(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue], main = paste("Total mRSP (without background correction) distribution for Well", well.name[i]),
         xlab = "Total mRSP per Object", col = "red", ylim = c(0, 2 * peaky), border = object.details.histogram.border, breaks = object.details.histogram.breaks,
         probability = TRUE, xlim = c(min(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, 0, na.rm = TRUE), 
                                      max(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, na.rm = TRUE)))
    
    lines(dens, col = object.details.densityline.color, lwd = object.details.densityline.width, lty = object.details.densityline.type)
    
    abline(v = peakx, lwd = 1.5, col = rgb(0, 0, 1, 0.5), lty = "longdash")
    text(peakx, 1.1 * max(dens$y), pos = 4, col = rgb(0, 0, 1, 1), srt = 90, cex = 1.2, labels = paste("Peak =", round(peakx, 2)), offset = -0.75)
    
    meantext <- NULL
    meantext <- mean(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue], na.rm = TRUE)
    abline(v = meantext, lwd = 1.5, col = rgb(1, 0, 0, 0.5), lty = "longdash")
    text(meantext, 1.1 * max(dens$y), pos = 4, lwd = 2, col = rgb(1, 0, 0, 1), offset = 0.75, srt = 90, cex = 1.2, labels = paste("Mean =", round(meantext, 2)))
    
    text(0.7 * max(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, na.rm = TRUE), 1.1 * max(dens$y), pos = 1, col = rgb(0, 0, 1, 1), cex = 1.5, srt = 0,
         labels = paste("n = ", length(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue]), sep = ""))
    
  }
  
}
dev.off()

# QC Plot 3 - Object Distribution, w.r.t. Current Well
print("Plotting Object Distribution, w.r.t. Current Well", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 3. Object Distribution (w.r.t. Current Well).pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 3 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.kinetic$well.id == well.name[i]
  
  # Plotting the data
  plotxtemp <- NA
  plotytemp <- NA
  
  plotxtemp <- cpdata.kinetic$AreaShape_Center_X[truthvalue]
  plotytemp <- cpdata.kinetic$AreaShape_Center_Y[truthvalue]
  
  if (length(plotxtemp) >= 200) {
    
    range.max <- round(max(plotxtemp, plotytemp), 0)
    range.min <- round(min(0, plotxtemp, plotytemp), 0)
    
  }
  
  if (length(plotxtemp) < 200) {
    
    range.max <- round(max(cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    range.min <- round(min(0, cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    
  }
  
  if(length(plotxtemp) == 0) {
    plot(-100, -100, col = rgb(0, 0, 0, 0.5), pch = 1, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]), axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
    axis(1)
    axis(2)
  }
  
  if(length(plotxtemp) != 0) {
    
    egfp.deno <- max(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue], 0, na.rm = TRUE)
    mrsp.deno <- max(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue], 0, na.rm = TRUE)
    
    egfp.intenstemp <- cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue]/egfp.deno
    mrsp.intenstemp <- cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue]/mrsp.deno
    
    egfp.intenstemp[is.nan(egfp.intenstemp)] <- 0
    mrsp.intenstemp[is.nan(mrsp.intenstemp)] <- 0
    
    plot(plotytemp ~ plotxtemp, col = rgb(0, 0, 0, 0.2), pch = 1, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
         xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
    axis(1)
    axis(2)
    
    for (k in 1:length(plotxtemp)) {
      intensity <- egfp.intenstemp[k]
      intensity <- max(intensity, 0)
      points(plotxtemp[k], plotytemp[k], col = rgb(0, 1, 0, intensity), pch = 16)
    }
    
    for (k in 1:length(plotxtemp)) {
      intensity <- mrsp.intenstemp[k]
      intensity <- max(intensity, 0)
      points(plotxtemp[k], plotytemp[k], col = rgb(1, 0, 0, intensity), pch = 16)
    }
    
  }
  
}
dev.off()

# QC Plot 4 - Object Distribution, w.r.t. All Wells
print("Plotting Object Distribution, w.r.t. All Wells", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 4. Object Distribution (w.r.t. All Wells).pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 4 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.kinetic$well.id == well.name[i]
  
  # Plotting the data
  plotxtemp <- NA
  plotytemp <- NA
  
  plotxtemp <- cpdata.kinetic$AreaShape_Center_X[truthvalue]
  plotytemp <- cpdata.kinetic$AreaShape_Center_Y[truthvalue]
  
  if (length(plotxtemp) >= 200) {
    
    range.max <- round(max(plotxtemp, plotytemp), 0)
    range.min <- round(min(0, plotxtemp, plotytemp), 0)
    
  }
  
  if (length(plotxtemp) < 200) {
    
    range.max <- round(max(cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    range.min <- round(min(0, cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    
  }
  
  if(length(plotxtemp) == 0) {
    plot(-100, -100, col = rgb(0, 0, 0, 0.5), pch = 1, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
         axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
    axis(1)
    axis(2)
  }
  
  if(length(plotxtemp) != 0) {
    
    egfp.deno <- max(cpdata.kinetic$Intensity_IntegratedIntensity_eGFP, 0, na.rm = TRUE)
    mrsp.deno <- max(cpdata.kinetic$Intensity_IntegratedIntensity_mRSP, 0, na.rm = TRUE)
    
    egfp.intenstemp <- cpdata.kinetic$Intensity_IntegratedIntensity_eGFP[truthvalue]/egfp.deno
    mrsp.intenstemp <- cpdata.kinetic$Intensity_IntegratedIntensity_mRSP[truthvalue]/mrsp.deno
    
    egfp.intenstemp[is.nan(egfp.intenstemp)] <- 0
    mrsp.intenstemp[is.nan(mrsp.intenstemp)] <- 0
    
    plot(plotytemp ~ plotxtemp, col = rgb(0, 0, 0, 0.2), pch = 1, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
         xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
    axis(1)
    axis(2)
    
    for (k in 1:length(plotxtemp)) {
      intensity <- egfp.intenstemp[k]
      intensity <- max(intensity, 0)
      points(plotxtemp[k], plotytemp[k], col = rgb(0, 1, 0, intensity), pch = 16)
    }
    
    for (k in 1:length(plotxtemp)) {
      intensity <- mrsp.intenstemp[k]
      intensity <- max(intensity, 0)
      points(plotxtemp[k], plotytemp[k], col = rgb(1, 0, 0, intensity), pch = 16)
    }
    
  }
  
}
dev.off()

# QC Plot 5 - Object Distribution Overall
print("Plotting Object Distribution Overall", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 5. Object Distribution Overall.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 5 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.kinetic$well.id == well.name[i]
  
  # Plotting the data
  plotxtemp <- NA
  plotytemp <- NA
  
  plotxtemp <- cpdata.kinetic$AreaShape_Center_X[truthvalue]
  plotytemp <- cpdata.kinetic$AreaShape_Center_Y[truthvalue]
  
  if (length(plotxtemp) >= 200) {
    
    range.max <- round(max(plotxtemp, plotytemp), 0)
    range.min <- round(min(0, plotxtemp, plotytemp), 0)
    
  }
  
  if (length(plotxtemp) < 200) {
    
    range.max <- round(max(cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    range.min <- round(min(0, cpdata.kinetic$AreaShape_Center_X, cpdata.kinetic$AreaShape_Center_Y), 0)
    
  }
  
  if(length(plotxtemp) == 0) {
    plot(-100, -100,col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
         axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
    axis(1)
    axis(2)
  }
  
  if(length(plotxtemp) != 0) {
    
    plot(plotytemp ~ plotxtemp, col = rgb(0, 0, 0, 1), pch = 20, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
         xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
    axis(1)
    axis(2)
    
  }
  
}
dev.off()

# QC Plot 6 - Saturated and Non-Saturated Object Distribution
print("Plotting Saturated and Non-Saturated Objects", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 6. Saturated and Non-Saturated Objects.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 6 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  truthvalue <- NULL
  truthvalue <- cpdata.all.objects.kinetic$well.id == well.name[i]
  
  # Plotting the data
  plotxtemp <- NA
  plotytemp <- NA
  
  plotxtemp <- cpdata.all.objects.kinetic$Location_Center_X[truthvalue]
  plotytemp <- cpdata.all.objects.kinetic$Location_Center_Y[truthvalue]
  
  if (length(plotxtemp) >= 200) {
    
    range.max <- round(max(plotxtemp, plotytemp), 0)
    range.min <- round(min(0, plotxtemp, plotytemp), 0)
    
  }
  
  if (length(plotxtemp) < 200) {
    
    range.max <- round(max(cpdata.all.objects.kinetic$Location_Center_X, cpdata.all.objects.kinetic$Location_Center_Y), 0)
    range.min <- round(min(0, cpdata.all.objects.kinetic$Location_Center_X, cpdata.all.objects.kinetic$Location_Center_Y), 0)
    
  }
  
  if(length(plotxtemp) == 0) {
    
    plot(-100, -100, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
         axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
    axis(1)
    axis(2)
    
  }
  
  if(length(plotxtemp) != 0) {
    
    plot(plotytemp ~ plotxtemp, col = rgb(0, 0, 1, 1), pch = 20, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
         xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
    axis(1)
    axis(2)
    
  }
  
}
dev.off()

# QC Plot 7 - Saturated mRSP Object Distribution
print("Plotting Saturated mRSP Objects", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 7. Saturated mRSP Objects.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 7 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  if(length(cpdata.saturated.mrsp.kinetic$well.id) > 0) {
    
    truthvalue <- NULL
    truthvalue <- cpdata.saturated.mrsp.kinetic$well.id == well.name[i]
    
    # Plotting the data
    plotxtemp <- NA
    plotytemp <- NA
    
    plotxtemp <- cpdata.saturated.mrsp.kinetic$Location_Center_X[truthvalue]
    plotytemp <- cpdata.saturated.mrsp.kinetic$Location_Center_Y[truthvalue]
    
    if (length(plotxtemp) >= 200) {
      
      range.max <- round(max(plotxtemp, plotytemp), 0)
      range.min <- round(min(0, plotxtemp, plotytemp), 0)
      
    }
    
    if (length(plotxtemp) < 200) {
      
      range.max <- round(max(cpdata.saturated.mrsp.kinetic$Location_Center_X, cpdata.saturated.mrsp.kinetic$Location_Center_Y), 0)
      range.min <- round(min(0, cpdata.saturated.mrsp.kinetic$Location_Center_X, cpdata.saturated.mrsp.kinetic$Location_Center_Y), 0)
      
    }
    
    if(length(plotxtemp) == 0) {
      
      plot(-100, -100, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
           axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
      axis(1)
      axis(2)
      
    }
    
    if(length(plotxtemp) != 0) {
      
      plot(plotytemp ~ plotxtemp, col = rgb(1, 0, 0, 1), pch = 20, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
           xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
      axis(1)
      axis(2)
      
    }
    
  }
  
}
dev.off()

# QC Plot 8 - Saturated eGFP Object Distribution
print("Plotting Saturated eGFP Objects", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 8. Saturated eGFP Objects.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 8 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  if(length(cpdata.saturated.egfp.kinetic$well.id) > 0) {
    
    truthvalue <- NULL
    truthvalue <- cpdata.saturated.egfp.kinetic$well.id == well.name[i]
    
    # Plotting the data
    plotxtemp <- NA
    plotytemp <- NA
    
    plotxtemp <- cpdata.saturated.egfp.kinetic$Location_Center_X[truthvalue]
    plotytemp <- cpdata.saturated.egfp.kinetic$Location_Center_Y[truthvalue]
    
    if (length(plotxtemp) >= 200) {
      
      range.max <- round(max(plotxtemp, plotytemp), 0)
      range.min <- round(min(0, plotxtemp, plotytemp), 0)
      
    }
    
    if (length(plotxtemp) < 200) {
      
      range.max <- round(max(cpdata.saturated.egfp.kinetic$Location_Center_X, cpdata.saturated.egfp.kinetic$Location_Center_Y), 0)
      range.min <- round(min(0, cpdata.saturated.egfp.kinetic$Location_Center_X, cpdata.saturated.egfp.kinetic$Location_Center_Y), 0)
      
    }
    
    if(length(plotxtemp) == 0) {
      
      plot(-100, -100, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
           axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
      axis(1)
      axis(2)
      
    }
    
    if(length(plotxtemp) != 0) {
      
      plot(plotytemp ~ plotxtemp, col = rgb(0, 1, 0, 1), pch = 20, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
           xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
      axis(1)
      axis(2)
      
    }
    
    
  }
  
}
dev.off()

# QC Plot 9 - Saturated BOTH Object Distribution
print("Plotting Overall Saturated Objects", quote = FALSE)
pdf(file = paste(subdirectory, pdfpath.qc, read.text, " - Quality Control Plot 9. Overall Saturated Objects.pdf", sep = ""), height = posterpdfheight, width = posterpdfwidth)
par(mfrow = c(scatterplotrows, scatterplotcolumns))
for (i in 1:length(well.name)) {
  
  cat(paste("Plotting QC Plot 9 for well", as.character(well.name[i]), "of plate", file.no, "\n"))
  
  if(length(cpdata.saturated.both.kinetic$well.id) > 0) {
    
    truthvalue <- NULL
    truthvalue <- cpdata.saturated.both.kinetic$well.id == well.name[i]
    
    # Plotting the data
    plotxtemp <- NA
    plotytemp <- NA
    
    plotxtemp <- cpdata.saturated.both.kinetic$Location_Center_X[truthvalue]
    plotytemp <- cpdata.saturated.both.kinetic$Location_Center_Y[truthvalue]
    
    if (length(plotxtemp) >= 200) {
      
      range.max <- round(max(plotxtemp, plotytemp), 0)
      range.min <- round(min(0, plotxtemp, plotytemp), 0)
      
    }
    
    if (length(plotxtemp) < 200) {
      
      range.max <- round(max(cpdata.saturated.both.kinetic$Location_Center_X, cpdata.saturated.both.kinetic$Location_Center_Y), 0)
      range.min <- round(min(0, cpdata.saturated.both.kinetic$Location_Center_X, cpdata.saturated.both.kinetic$Location_Center_Y), 0)
      
    }
    
    if(length(plotxtemp) == 0) {
      
      plot(-100, -100, col = rgb(0, 0, 0, 1), pch = 20, xlab = "X-Axis", ylab = "Y-Axis", main = paste("No Data Found. Display cancelled for", well.name[i]),
           axes = FALSE, xlim = c(range.min, range.max), ylim = c(range.min, range.max))
      axis(1)
      axis(2)
      
    }
    
    if(length(plotxtemp) != 0) {
      
      plot(plotytemp ~ plotxtemp, col = rgb(0, 1, 1, 1), pch = 20, main = paste("Object Distribution", well.name[i], "; n =", length(plotxtemp)),
           xlab = "X-Axis", ylab = "Y-Axis", xlim = c(range.min, range.max), ylim = c(range.min, range.max), axes = FALSE)
      axis(1)
      axis(2)
      
    }
    
  }
  
}
dev.off()

cat("Level 1 Quality-Control diagrams have been created.\n")