## VERY IMPORTANT : Before running this script, use setwd() function to set the working directory.
setwd("/scicore/projects/scicore-p-maiert-structbio/shubham/Login19_Process/SSCP-PL11/210922_154252_Dummy/")

rm(list = ls())
only.endflo.analysis <- TRUE

## Path where all the supplementary scripts are present.
sourcecode.path <- "/scicore/projects/scicore-p-maiert-structbio/shubham/Final_Data/Pipelines/R_Source_Code/"

# Define the layout for the plate
source(file = paste(sep = "", sourcecode.path, "01. Plate Settings.R"))

# Define the parameters for the graphical elements
source(file = paste(sep = "", sourcecode.path, "02. Graphics Settings.R"))

# Defines the plate structure of the experiment and loads the necessary functions
source(file = paste(sep = "", sourcecode.path, "03. Input Output Settings.R"))

cat("Supplementary Scripts Loaded Successfully.")

constant.output.file <- NULL
constant.output.file <- paste(generatedfilesfolder, runtime, "- Endpoint Fluorescence.csv", sep = "")

aggregating.output.file <- NULL
aggregating.output.file <- paste(generatedfilesfolder, "Endpoint Fluorescence - Multiple-Experiment-Data Aggregating File.csv", sep = "")

file.no <- NULL
for (file.no in 1:length(filelist)) {
  
  dataread <- NULL
  dataread <- read.csv(file = filelist[file.no], header = TRUE, sep = "\t", row.names = NULL)
  
  # Set all ERROR values to 0 or NA.
  dataread[dataread == "ERROR"] <- as.numeric(NA)
  colnames(dataread)[length(dataread)] <- "measurements"
  
  # Convert characters to numerics
  for (t in 2:as.numeric(length(dataread)-1)) { dataread[, t] <- as.numeric(as.character(dataread[, t])) }
  dataread$measurements <- factor(dataread$measurements)
  
  cat(paste("Processing File -", filelist[file.no]))
  
  cpsummary <- NULL
  cpsummary <-
    data.frame(
      well.id = character(),
      well.row = character(),
      well.column = integer(),
      read.egfp = double(),
      read.mrsp = double(),
      blk.corr.egfp = double(),
      blk.corr.mrsp = double(),
      xprsn.ratio = double(),
      xprsn.normal = double(),
      norm.total.egfp = double(),
      norm.total.mrsp = double(),
      bottom.or.top = factor(),
      stringsAsFactors = FALSE)
  
  for (i in 1:length(wellrows)) {
    
    temp.subset <- subset(dataread, dataread$row.names == wellrows[i])
    temp.subset$row.names <- NULL
    
    temp.read.egfp <- temp.subset[temp.subset$measurements == "Endpoint Fluorescence:465,510", ]
    temp.read.mrsp <- temp.subset[temp.subset$measurements == "Endpoint Fluorescence:570,640", ]
    
    temp.blk.corr.egfp <- temp.subset[temp.subset$measurements == "BLK Corr. eGFP - Only High", ]
    temp.blk.corr.mrsp <- temp.subset[temp.subset$measurements == "BLK Corr. mRSP - Only High", ]
    
    temp.xprsn.ratio <- temp.subset[temp.subset$measurements == "eGFP to mRSP - Lysate Fluorescence", ]
    temp.xprsn.normal <- temp.subset[temp.subset$measurements == "Estimated UAA Incorporation - Lysate Based", ]
    
    temp.norm.egfp <- temp.subset[temp.subset$measurements == "Normalized eGFP", ]
    temp.norm.mrsp <- temp.subset[temp.subset$measurements == "Normalized mRSP", ]
    
    for (j in 1:as.numeric(length(temp.subset)-1)) {
      well.id <- NULL
      well.id <- paste(wellrows[i], wellcolumns[j], sep = "")
      
      cpsummary.temp <- NULL
      cpsummary.temp <-
        c(
          well.id,
          wellrows[i],
          as.numeric(wellcolumns[j]),
          temp.read.egfp[j],
          temp.read.mrsp[j],
          temp.blk.corr.egfp[j],
          temp.blk.corr.mrsp[j],
          temp.xprsn.ratio[j],
          temp.xprsn.normal[j],
          temp.norm.egfp[j],
          temp.norm.mrsp[j],
          names(well.name[well.name == well.id])
        )
      
      levels(cpsummary$bottom.or.top) <- c(levels(cpsummary$bottom.or.top), names(well.name[well.name == well.id]))
      
      names(cpsummary.temp) <-
        c(
          "well.id",
          "well.row",
          "well.column",
          "read.egfp",
          "read.mrsp",
          "blk.corr.egfp",
          "blk.corr.mrsp",
          "xprsn.ratio",
          "xprsn.normal",
          "norm.total.egfp",
          "norm.total.mrsp",
          "bottom.or.top"
        )
      
      cpsummary$well.id <- as.character(cpsummary$well.id)
      cpsummary$well.row <- as.character(cpsummary$well.row)
      
      cpsummary <- rbind(cpsummary, cpsummary.temp)
      
      rm(cpsummary.temp)
    }
    
  }
  
  cpsummary$well.id <- factor(cpsummary$well.id)
  cpsummary$well.row <- factor(cpsummary$well.row)
  cpsummary$well.column <- factor(cpsummary$well.column)
  cpsummary$Metadata_Well <- cpsummary$well.id
  
  cpsummary.debug <- cpsummary  
  
  #Assigning well.all and sample types
  allocate.dataframe <- cpsummary
  source(file = paste(sep = "", sourcecode.path, "04. Allocate Group.R"))
  cpsummary <- allocate.dataframe
  sample.detail.df <- cpsummary
  source(file = paste(sep = "", sourcecode.path, "05. Sample Detail.R"))
  cpsummary <- sample.detail.df
  rm(sample.detail.df)
  rm(allocate.dataframe)
  
  cpsummary$plate.info <- filelist[file.no]
  cpsummary$plate.info <- factor(cpsummary$plate.info)
  
  file.list <- list.files(path = generatedfilesfolder)
  file.list <- paste(generatedfilesfolder, file.list, sep = "")
  
  if (length(file.list[file.list == constant.output.file]) != 0) {
    write.table(cpsummary, file = constant.output.file, append = TRUE, row.names = FALSE,
                sep = ",", na = "NA", dec = ".", col.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == constant.output.file]) == 0) {
    write.csv(cpsummary, file = constant.output.file, na = "NA", row.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == aggregating.output.file]) != 0) {
    write.table(cpsummary, file = aggregating.output.file, append = TRUE, row.names = FALSE, sep = ",",
                na = "NA", dec = ".", col.names = FALSE, quote = FALSE)
  }
  
  if (length(file.list[file.list == aggregating.output.file]) == 0) {
    write.csv(cpsummary, file = aggregating.output.file, na = "NA", row.names = FALSE, quote = FALSE)
  }
  
  rm(cpsummary)
  
}

cat("\n\nAll CSV Processing complete\n\n")